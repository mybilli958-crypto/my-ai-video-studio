package com.example

import com.example.i18n.AppLanguage
import com.example.i18n.stringsFor
import com.example.model.ProviderAdapterId
import com.example.provider.ProviderCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StudioProviderAndStringsTest {

    @Test
    fun demoProviderCapabilities_areHonestAndNonEmpty() {
        val demo = ProviderCatalog.capabilitiesFor(ProviderAdapterId.DEMO_MODE)
        assertTrue(demo.isDemo)
        assertFalse(demo.requiresBackendUrl)
        assertFalse(demo.supportsNativeVideoContinuation)
        assertTrue(demo.supportedDurationsSeconds.isNotEmpty())
        assertTrue(demo.supportedAspectRatios.size == 3)
    }

    @Test
    fun externalProviderCapabilities_requireBackendUrl() {
        val veo = ProviderCatalog.capabilitiesFor(ProviderAdapterId.GOOGLE_VEO_BACKEND)
        val runway = ProviderCatalog.capabilitiesFor(ProviderAdapterId.RUNWAY_BACKEND)
        assertFalse(veo.isDemo)
        assertTrue(veo.requiresBackendUrl)
        assertTrue(veo.supportsNativeVideoContinuation)
        assertFalse(runway.supportsNativeVideoContinuation)
    }

    @Test
    fun bilingualStrings_containEnglishAndBengaliTranslations() {
        val en = stringsFor(AppLanguage.ENGLISH)
        val bn = stringsFor(AppLanguage.BENGALI)
        assertEquals("My AI Video Studio", en.appTitle)
        assertEquals("My AI Video Studio", bn.appTitle)
        assertTrue(en.generateVideoBtn.isNotBlank())
        assertTrue(bn.generateVideoBtn.isNotBlank())
        assertTrue(en.generateVideoBtn != bn.generateVideoBtn)
        assertTrue(en.exportTitle != bn.exportTitle)
    }
}

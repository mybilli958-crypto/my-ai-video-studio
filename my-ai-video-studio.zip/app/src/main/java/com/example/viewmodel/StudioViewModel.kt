package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ProjectWithClips
import com.example.data.local.SettingsPreferencesRepository
import com.example.data.local.StoryProjectEntity
import com.example.data.local.StudioDatabase
import com.example.data.local.StudioSettings
import com.example.data.local.VideoClipEntity
import com.example.i18n.AppLanguage
import com.example.i18n.StudioStrings
import com.example.i18n.stringsFor
import com.example.media.InternalExportEvent
import com.example.media.VideoExportManager
import com.example.media.VideoFrameExtractor
import com.example.model.AspectRatioOption
import com.example.model.ExportUiState
import com.example.model.GenerationUiState
import com.example.model.ProviderAdapterId
import com.example.model.ProviderCapabilities
import com.example.model.ProviderStatus
import com.example.model.VideoGenerationRequest
import com.example.model.VideoGenerationResult
import com.example.model.VideoStyle
import com.example.provider.BackendAdapterVideoProvider
import com.example.provider.DemoVideoProvider
import com.example.provider.ProviderCatalog
import com.example.provider.VideoGenerationProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

data class ComposerState(
    val prompt: String = "",
    val continuityContext: String = "",
    val style: VideoStyle = VideoStyle.REALISTIC_CINEMATIC,
    val aspectRatio: AspectRatioOption = AspectRatioOption.PORTRAIT_9_16,
    val durationSeconds: Int = 5,
    val referenceImagePath: String? = null,
    val isExtendMode: Boolean = false,
    val extendSourceClip: VideoClipEntity? = null
)

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val dao = StudioDatabase.getInstance(appContext).studioDao()
    private val prefsRepo = SettingsPreferencesRepository(appContext)

    val settings: StateFlow<StudioSettings> = prefsRepo.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = StudioSettings()
    )

    val strings: StateFlow<StudioStrings> = settings
        .map { stringsFor(it.language) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = stringsFor(AppLanguage.ENGLISH)
        )

    val activeCapabilities: StateFlow<ProviderCapabilities> = settings
        .map { ProviderCatalog.capabilitiesFor(it.selectedAdapterId) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = ProviderCatalog.capabilitiesFor(ProviderAdapterId.DEMO_MODE)
        )

    val projects: StateFlow<List<ProjectWithClips>> = dao.observeAllProjectsWithClips()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val recentClips: StateFlow<List<VideoClipEntity>> = dao.observeRecentClips(12)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    @Suppress("OPT_IN_USAGE")
    val activeProject: StateFlow<ProjectWithClips?> = combine(
        settings.map { it.activeProjectId },
        projects
    ) { activeId, projectList ->
        if (activeId > 0L) {
            projectList.firstOrNull { it.project.id == activeId } ?: projectList.firstOrNull()
        } else {
            projectList.firstOrNull()
        }
    }.flatMapLatest { resolved ->
        if (resolved == null) flowOf(null) else dao.observeProjectWithClips(resolved.project.id)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    private val _selectedClipId = MutableStateFlow<Long?>(null)
    val selectedClipId: StateFlow<Long?> = _selectedClipId.asStateFlow()

    private val _previewFullStory = MutableStateFlow(false)
    val previewFullStory: StateFlow<Boolean> = _previewFullStory.asStateFlow()

    private val _composerState = MutableStateFlow(ComposerState())
    val composerState: StateFlow<ComposerState> = _composerState.asStateFlow()

    private val _generationState = MutableStateFlow<GenerationUiState>(GenerationUiState.Idle)
    val generationState: StateFlow<GenerationUiState> = _generationState.asStateFlow()

    private val _exportState = MutableStateFlow<ExportUiState>(ExportUiState.Idle)
    val exportState: StateFlow<ExportUiState> = _exportState.asStateFlow()

    private val _providerStatus = MutableStateFlow<ProviderStatus?>(null)
    val providerStatus: StateFlow<ProviderStatus?> = _providerStatus.asStateFlow()

    private val _isTestingConnection = MutableStateFlow(false)
    val isTestingConnection: StateFlow<Boolean> = _isTestingConnection.asStateFlow()

    private var generationJob: Job? = null
    private var exportJob: Job? = null

    init {
        viewModelScope.launch {
            activeCapabilities.collect { caps ->
                val currentDuration = _composerState.value.durationSeconds
                if (currentDuration !in caps.supportedDurationsSeconds) {
                    _composerState.value = _composerState.value.copy(
                        durationSeconds = caps.supportedDurationsSeconds.firstOrNull() ?: 5
                    )
                }
                val currentAspect = _composerState.value.aspectRatio
                if (currentAspect !in caps.supportedAspectRatios) {
                    _composerState.value = _composerState.value.copy(
                        aspectRatio = caps.supportedAspectRatios.firstOrNull()
                            ?: AspectRatioOption.PORTRAIT_9_16
                    )
                }
            }
        }
    }

    private fun buildActiveProvider(currentSettings: StudioSettings): VideoGenerationProvider {
        val caps = ProviderCatalog.capabilitiesFor(currentSettings.selectedAdapterId)
        return if (caps.isDemo) {
            DemoVideoProvider(appContext)
        } else {
            BackendAdapterVideoProvider(
                context = appContext,
                capabilities = caps,
                baseUrl = currentSettings.backendBaseUrl,
                bearerToken = currentSettings.backendClientToken
            )
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            prefsRepo.setLanguage(language)
        }
    }

    fun toggleLanguage() {
        val next = if (settings.value.language == AppLanguage.ENGLISH) {
            AppLanguage.BENGALI
        } else {
            AppLanguage.ENGLISH
        }
        setLanguage(next)
    }

    fun createNewProject(
        title: String,
        style: VideoStyle = VideoStyle.REALISTIC_CINEMATIC,
        aspectRatio: AspectRatioOption = AspectRatioOption.PORTRAIT_9_16,
        onCreated: (Long) -> Unit = {}
    ) {
        viewModelScope.launch {
            val cleanTitle = title.trim().ifBlank { strings.value.defaultProjectTitle }
            val newId = dao.insertProject(
                StoryProjectEntity(
                    title = cleanTitle,
                    aspectRatioId = aspectRatio.id,
                    styleId = style.id
                )
            )
            prefsRepo.setActiveProjectId(newId)
            _selectedClipId.value = null
            _previewFullStory.value = false
            _exportState.value = ExportUiState.Idle
            _generationState.value = GenerationUiState.Idle
            _composerState.value = ComposerState(
                style = style,
                aspectRatio = aspectRatio,
                durationSeconds = activeCapabilities.value.supportedDurationsSeconds.firstOrNull() ?: 5
            )
            onCreated(newId)
        }
    }

    fun openProject(projectId: Long, clipIdToSelect: Long? = null) {
        viewModelScope.launch {
            prefsRepo.setActiveProjectId(projectId)
            val loaded = dao.observeProjectWithClips(projectId).first()
            val clips = loaded?.orderedClips.orEmpty()
            _selectedClipId.value = clipIdToSelect ?: clips.lastOrNull()?.id
            _previewFullStory.value = false
            _exportState.value = ExportUiState.Idle
            _generationState.value = GenerationUiState.Idle
            loaded?.let { proj ->
                _composerState.value = _composerState.value.copy(
                    style = VideoStyle.fromId(proj.project.styleId),
                    aspectRatio = AspectRatioOption.fromId(proj.project.aspectRatioId),
                    continuityContext = proj.project.continuityNotes,
                    isExtendMode = false,
                    extendSourceClip = null
                )
            }
        }
    }

    fun renameActiveProject(newTitle: String) {
        val current = activeProject.value?.project ?: return
        val trimmed = newTitle.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch {
            dao.updateProject(current.copy(title = trimmed, updatedAt = System.currentTimeMillis()))
        }
    }

    fun deleteProject(projectId: Long) {
        viewModelScope.launch {
            val projectWithClips = dao.observeProjectWithClips(projectId).first()
            projectWithClips?.clips?.forEach { clip ->
                runCatching { File(clip.videoFilePath).delete() }
                runCatching { File(clip.thumbnailPath).delete() }
            }
            dao.deleteProjectById(projectId)
            if (settings.value.activeProjectId == projectId) {
                prefsRepo.setActiveProjectId(-1L)
            }
        }
    }

    fun selectClipForPreview(clipId: Long) {
        _selectedClipId.value = clipId
        _previewFullStory.value = false
    }

    fun togglePreviewFullStory(fullStory: Boolean) {
        _previewFullStory.value = fullStory
    }

    fun updatePrompt(text: String) {
        _composerState.value = _composerState.value.copy(prompt = text)
        if (_generationState.value is GenerationUiState.Error) {
            _generationState.value = GenerationUiState.Idle
        }
    }

    fun updateContinuityContext(text: String) {
        _composerState.value = _composerState.value.copy(continuityContext = text)
    }

    fun updateStyle(style: VideoStyle) {
        _composerState.value = _composerState.value.copy(style = style)
    }

    fun updateAspectRatio(aspectRatio: AspectRatioOption) {
        _composerState.value = _composerState.value.copy(aspectRatio = aspectRatio)
    }

    fun updateDuration(seconds: Int) {
        _composerState.value = _composerState.value.copy(durationSeconds = seconds)
    }

    fun attachPickedReferenceImage(uri: Uri) {
        viewModelScope.launch {
            val copiedPath = VideoFrameExtractor.copyUriToInternalRef(appContext, uri)
            if (copiedPath != null) {
                _composerState.value = _composerState.value.copy(referenceImagePath = copiedPath)
            }
        }
    }

    fun clearReferenceImage() {
        _composerState.value = _composerState.value.copy(referenceImagePath = null)
    }

    fun startAddNextClipFlow(previousClip: VideoClipEntity) {
        viewModelScope.launch {
            val extractedFrame = VideoFrameExtractor.extractLastFrame(
                context = appContext,
                videoFilePath = previousClip.videoFilePath,
                outputTag = "clip_${previousClip.id}"
            )
            val inheritedContext = previousClip.continuityContext.ifBlank {
                previousClip.prompt.take(120)
            }
            _composerState.value = _composerState.value.copy(
                prompt = "",
                continuityContext = inheritedContext,
                style = VideoStyle.fromId(previousClip.styleId),
                aspectRatio = AspectRatioOption.fromId(previousClip.aspectRatioId),
                referenceImagePath = extractedFrame,
                isExtendMode = true,
                extendSourceClip = previousClip
            )
            _generationState.value = GenerationUiState.Idle
        }
    }

    fun cancelExtendMode() {
        _composerState.value = _composerState.value.copy(
            isExtendMode = false,
            extendSourceClip = null,
            referenceImagePath = null
        )
    }

    fun generateClip() {
        val currentComposer = _composerState.value
        val currentStrings = strings.value
        val promptClean = currentComposer.prompt.trim()
        if (promptClean.isEmpty()) {
            _generationState.value = GenerationUiState.Error(currentStrings.errorMissingPrompt)
            return
        }

        val currentSettings = settings.value
        val caps = ProviderCatalog.capabilitiesFor(currentSettings.selectedAdapterId)
        if (caps.requiresBackendUrl && currentSettings.backendBaseUrl.isBlank()) {
            _generationState.value = GenerationUiState.Error(currentStrings.errorMissingBackendUrl)
            return
        }

        generationJob?.cancel()
        generationJob = viewModelScope.launch {
            try {
                _generationState.value = GenerationUiState.Generating(
                    0.02f,
                    "${currentStrings.generatingStatusPrefix}..."
                )

                val project = ensureActiveProject(currentComposer)
                val existingClips = dao.getClipsForProject(project.id).sortedBy { it.orderIndex }
                val nextOrderIndex = existingClips.size
                val effectiveAspectRatio = if (existingClips.isNotEmpty()) {
                    AspectRatioOption.fromId(project.aspectRatioId)
                } else {
                    currentComposer.aspectRatio
                }

                val provider = buildActiveProvider(currentSettings)
                val extendSource = currentComposer.extendSourceClip
                val req = VideoGenerationRequest(
                    projectId = project.id,
                    sceneNumber = nextOrderIndex + 1,
                    prompt = promptClean,
                    continuityContext = currentComposer.continuityContext.trim(),
                    style = currentComposer.style,
                    aspectRatio = effectiveAspectRatio,
                    durationSeconds = currentComposer.durationSeconds,
                    referenceImagePath = currentComposer.referenceImagePath,
                    previousClipId = extendSource?.id,
                    previousRemoteGenerationId = extendSource?.remoteGenerationId,
                    isExtensionFlow = currentComposer.isExtendMode && extendSource != null
                )

                val result = if (req.isExtensionFlow && extendSource != null) {
                    provider.extendClip(req, extendSource) { progress, status ->
                        _generationState.value = GenerationUiState.Generating(progress, status)
                    }
                } else {
                    provider.generateClip(req) { progress, status ->
                        _generationState.value = GenerationUiState.Generating(progress, status)
                    }
                }

                when (result) {
                    is VideoGenerationResult.Success -> {
                        val savedClipId = dao.insertClip(
                            VideoClipEntity(
                                projectId = project.id,
                                orderIndex = nextOrderIndex,
                                prompt = promptClean,
                                continuityContext = currentComposer.continuityContext.trim(),
                                styleId = currentComposer.style.id,
                                aspectRatioId = effectiveAspectRatio.id,
                                durationSeconds = result.durationSeconds,
                                videoFilePath = result.videoFilePath,
                                thumbnailPath = result.thumbnailPath,
                                referenceImagePath = currentComposer.referenceImagePath,
                                originId = result.origin.id,
                                continuityModeId = result.continuityMode.id,
                                providerName = result.providerName,
                                remoteGenerationId = result.remoteGenerationId
                            )
                        )
                        dao.updateProject(
                            project.copy(
                                aspectRatioId = effectiveAspectRatio.id,
                                styleId = currentComposer.style.id,
                                continuityNotes = currentComposer.continuityContext.trim(),
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                        _selectedClipId.value = savedClipId
                        _previewFullStory.value = false
                        _exportState.value = ExportUiState.Idle
                        _composerState.value = _composerState.value.copy(
                            prompt = "",
                            isExtendMode = false,
                            extendSourceClip = null
                        )
                        _generationState.value = GenerationUiState.Idle
                    }

                    is VideoGenerationResult.Error -> {
                        _generationState.value = GenerationUiState.Error(
                            message = result.message,
                            detail = result.technicalDetail
                        )
                    }
                }
            } catch (e: CancellationException) {
                _generationState.value = GenerationUiState.Idle
                throw e
            } catch (e: Exception) {
                _generationState.value = GenerationUiState.Error(
                    message = e.localizedMessage ?: "Video generation failed."
                )
            }
        }
    }

    fun cancelGeneration() {
        generationJob?.cancel()
        generationJob = null
        _generationState.value = GenerationUiState.Idle
    }

    fun regenerateClip(clip: VideoClipEntity) {
        val currentSettings = settings.value
        val caps = ProviderCatalog.capabilitiesFor(currentSettings.selectedAdapterId)
        val currentStrings = strings.value
        if (caps.requiresBackendUrl && currentSettings.backendBaseUrl.isBlank()) {
            _generationState.value = GenerationUiState.Error(currentStrings.errorMissingBackendUrl)
            return
        }

        generationJob?.cancel()
        generationJob = viewModelScope.launch {
            try {
                _generationState.value = GenerationUiState.Generating(
                    0.05f,
                    "${currentStrings.regenerateClip}..."
                )
                val provider = buildActiveProvider(currentSettings)
                val req = VideoGenerationRequest(
                    projectId = clip.projectId,
                    sceneNumber = clip.orderIndex + 1,
                    prompt = clip.prompt,
                    continuityContext = clip.continuityContext,
                    style = VideoStyle.fromId(clip.styleId),
                    aspectRatio = AspectRatioOption.fromId(clip.aspectRatioId),
                    durationSeconds = clip.durationSeconds,
                    referenceImagePath = clip.referenceImagePath
                )
                val result = provider.generateClip(req) { progress, status ->
                    _generationState.value = GenerationUiState.Generating(progress, status)
                }
                when (result) {
                    is VideoGenerationResult.Success -> {
                        runCatching { File(clip.videoFilePath).delete() }
                        runCatching { File(clip.thumbnailPath).delete() }
                        dao.updateClip(
                            clip.copy(
                                videoFilePath = result.videoFilePath,
                                thumbnailPath = result.thumbnailPath,
                                originId = result.origin.id,
                                providerName = result.providerName,
                                remoteGenerationId = result.remoteGenerationId,
                                createdAt = System.currentTimeMillis()
                            )
                        )
                        _selectedClipId.value = clip.id
                        _exportState.value = ExportUiState.Idle
                        _generationState.value = GenerationUiState.Idle
                    }
                    is VideoGenerationResult.Error -> {
                        _generationState.value = GenerationUiState.Error(result.message, result.technicalDetail)
                    }
                }
            } catch (e: CancellationException) {
                _generationState.value = GenerationUiState.Idle
                throw e
            } catch (e: Exception) {
                _generationState.value = GenerationUiState.Error(e.localizedMessage ?: "Regeneration failed.")
            }
        }
    }

    fun moveClipEarlier(clip: VideoClipEntity) {
        viewModelScope.launch {
            val ordered = dao.getClipsForProject(clip.projectId).sortedBy { it.orderIndex }
            val idx = ordered.indexOfFirst { it.id == clip.id }
            if (idx > 0) {
                dao.swapClipsOrder(ordered[idx], ordered[idx - 1])
                _exportState.value = ExportUiState.Idle
            }
        }
    }

    fun moveClipLater(clip: VideoClipEntity) {
        viewModelScope.launch {
            val ordered = dao.getClipsForProject(clip.projectId).sortedBy { it.orderIndex }
            val idx = ordered.indexOfFirst { it.id == clip.id }
            if (idx in 0 until ordered.lastIndex) {
                dao.swapClipsOrder(ordered[idx], ordered[idx + 1])
                _exportState.value = ExportUiState.Idle
            }
        }
    }

    fun removeClip(clip: VideoClipEntity) {
        viewModelScope.launch {
            runCatching { File(clip.videoFilePath).delete() }
            runCatching { File(clip.thumbnailPath).delete() }
            dao.deleteClipAndReindex(clip.projectId, clip.id)
            if (_selectedClipId.value == clip.id) {
                val remaining = dao.getClipsForProject(clip.projectId).sortedBy { it.orderIndex }
                _selectedClipId.value = remaining.lastOrNull()?.id
            }
            _exportState.value = ExportUiState.Idle
        }
    }

    fun exportFinalMp4() {
        val projectWithClips = activeProject.value ?: return
        val ordered = projectWithClips.orderedClips
        if (ordered.isEmpty()) {
            _exportState.value = ExportUiState.Failed(strings.value.exportEmptySubtitle)
            return
        }

        exportJob?.cancel()
        exportJob = viewModelScope.launch {
            _exportState.value = ExportUiState.Exporting(0)
            VideoExportManager.joinClipsToMp4(
                context = appContext,
                projectId = projectWithClips.project.id,
                clips = ordered
            ).collect { event ->
                when (event) {
                    is InternalExportEvent.Progress -> {
                        _exportState.value = ExportUiState.Exporting(event.percent)
                    }
                    is InternalExportEvent.Success -> {
                        dao.updateProject(
                            projectWithClips.project.copy(
                                lastExportedPath = event.outputPath,
                                lastExportedAt = System.currentTimeMillis(),
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                        _exportState.value = ExportUiState.Completed(
                            outputFilePath = event.outputPath,
                            fileSizeBytes = event.sizeBytes,
                            clipCount = ordered.size
                        )
                    }
                    is InternalExportEvent.Error -> {
                        _exportState.value = ExportUiState.Failed(event.message)
                    }
                }
            }
        }
    }

    fun saveExportedMp4ToMovies() {
        val completed = _exportState.value as? ExportUiState.Completed ?: return
        val title = activeProject.value?.project?.title ?: "MyAIVideoStudio"
        viewModelScope.launch {
            val result = VideoExportManager.saveMp4ToMovies(
                context = appContext,
                sourcePath = completed.outputFilePath,
                displayTitle = title
            )
            result.onSuccess { uriString ->
                _exportState.value = completed.copy(savedToGalleryUri = uriString)
            }.onFailure { err ->
                _exportState.value = ExportUiState.Failed(
                    err.localizedMessage ?: "Failed to save MP4 to Movies folder."
                )
            }
        }
    }

    fun saveProviderConfig(
        adapterId: ProviderAdapterId,
        backendUrl: String,
        backendToken: String
    ) {
        viewModelScope.launch {
            prefsRepo.saveProviderConfig(adapterId, backendUrl, backendToken)
            _providerStatus.value = null
        }
    }

    fun testBackendConnection(
        adapterId: ProviderAdapterId,
        backendUrl: String,
        backendToken: String
    ) {
        viewModelScope.launch {
            _isTestingConnection.value = true
            prefsRepo.saveProviderConfig(adapterId, backendUrl, backendToken)
            val caps = ProviderCatalog.capabilitiesFor(adapterId)
            val status = if (caps.isDemo) {
                DemoVideoProvider(appContext).checkStatus()
            } else {
                BackendAdapterVideoProvider(appContext, caps, backendUrl, backendToken).checkStatus()
            }
            _providerStatus.value = status
            _isTestingConnection.value = false
        }
    }

    private suspend fun ensureActiveProject(composer: ComposerState): StoryProjectEntity {
        val current = activeProject.value?.project
        if (current != null) return current
        val newId = dao.insertProject(
            StoryProjectEntity(
                title = strings.value.defaultProjectTitle,
                aspectRatioId = composer.aspectRatio.id,
                styleId = composer.style.id,
                continuityNotes = composer.continuityContext
            )
        )
        prefsRepo.setActiveProjectId(newId)
        return dao.getProjectById(newId)
            ?: throw IllegalStateException("Failed to create story project.")
    }
}

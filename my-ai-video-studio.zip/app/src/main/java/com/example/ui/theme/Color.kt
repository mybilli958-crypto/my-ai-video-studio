package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StudioBlack = Color(0xFF06050A)
val ObsidianSurface = Color(0xFF0F0C18)
val ObsidianCard = Color(0xFF171226)
val ObsidianElevated = Color(0xFF211A36)
val ObsidianBorder = Color(0xFF2E244D)

val ElectricPurple = Color(0xFF9333EA)
val NeonViolet = Color(0xFFA855F7)
val DeepRoyalPurple = Color(0xFF581C87)
val SoftLavender = Color(0xFFD8B4FE)
val MutedVioletText = Color(0xFFA89EC4)
val CrispWhiteText = Color(0xFFF6F4FA)

val DemoAmber = Color(0xFFF59E0B)
val DemoAmberContainer = Color(0xFF3A2408)
val AiCyan = Color(0xFF38BDF8)
val AiCyanContainer = Color(0xFF0B293D)
val ExportEmerald = Color(0xFF10B981)
val ExportEmeraldContainer = Color(0xFF082D21)
val ErrorCrimson = Color(0xFFEF4444)
val ErrorCrimsonContainer = Color(0xFF3B0D12)

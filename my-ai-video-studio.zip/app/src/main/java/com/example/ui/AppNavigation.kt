package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Outbox
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MovieCreation
import androidx.compose.material.icons.outlined.Outbox
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.components.StudioTopHeader
import com.example.ui.screens.ExportScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StudioScreen
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.SoftLavender
import com.example.ui.theme.StudioBlack
import com.example.viewmodel.StudioViewModel

const val ROUTE_HOME = "home"
const val ROUTE_STUDIO = "studio"
const val ROUTE_EXPORT = "export"
const val ROUTE_SETTINGS = "settings"

private data class StudioNavDestination(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@Composable
fun StudioAppRoot(viewModel: StudioViewModel) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_HOME

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val strings by viewModel.strings.collectAsStateWithLifecycle()
    val capabilities by viewModel.activeCapabilities.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val recentClips by viewModel.recentClips.collectAsStateWithLifecycle()
    val activeProject by viewModel.activeProject.collectAsStateWithLifecycle()
    val selectedClipId by viewModel.selectedClipId.collectAsStateWithLifecycle()
    val previewFullStory by viewModel.previewFullStory.collectAsStateWithLifecycle()
    val composer by viewModel.composerState.collectAsStateWithLifecycle()
    val generationState by viewModel.generationState.collectAsStateWithLifecycle()
    val exportState by viewModel.exportState.collectAsStateWithLifecycle()
    val providerStatus by viewModel.providerStatus.collectAsStateWithLifecycle()
    val isTestingConnection by viewModel.isTestingConnection.collectAsStateWithLifecycle()

    val destinations = listOf(
        StudioNavDestination(
            route = ROUTE_HOME,
            label = strings.navHome,
            selectedIcon = Icons.Filled.Home,
            unselectedIcon = Icons.Outlined.Home,
            testTag = "nav_home"
        ),
        StudioNavDestination(
            route = ROUTE_STUDIO,
            label = strings.navStudio,
            selectedIcon = Icons.Filled.MovieCreation,
            unselectedIcon = Icons.Outlined.MovieCreation,
            testTag = "nav_studio"
        ),
        StudioNavDestination(
            route = ROUTE_EXPORT,
            label = strings.navExport,
            selectedIcon = Icons.Filled.Outbox,
            unselectedIcon = Icons.Outlined.Outbox,
            testTag = "nav_export"
        ),
        StudioNavDestination(
            route = ROUTE_SETTINGS,
            label = strings.navSettings,
            selectedIcon = Icons.Filled.Settings,
            unselectedIcon = Icons.Outlined.Settings,
            testTag = "nav_settings"
        )
    )

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBlack)
    ) {
        val useRail = maxWidth >= 720.dp

        Scaffold(
            containerColor = StudioBlack,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                Column(
                    modifier = Modifier
                        .background(ObsidianSurface)
                        .windowInsetsPadding(WindowInsets.statusBars)
                ) {
                    StudioTopHeader(
                        title = strings.appTitle,
                        strings = strings,
                        settings = settings,
                        capabilities = capabilities,
                        onToggleLanguage = { viewModel.toggleLanguage() },
                        onBadgeClick = { navigateTo(ROUTE_SETTINGS) }
                    )
                    HorizontalDivider(color = ObsidianBorder, thickness = 1.dp)
                }
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = ObsidianSurface,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        destinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label
                                    )
                                },
                                label = { Text(dest.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = SoftLavender,
                                    indicatorColor = ElectricPurple,
                                    unselectedIconColor = Color(0xFF8C82A8),
                                    unselectedTextColor = Color(0xFF8C82A8)
                                ),
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(
                        containerColor = ObsidianSurface,
                        modifier = Modifier
                            .fillMaxHeight()
                            .windowInsetsPadding(WindowInsets.navigationBars)
                    ) {
                        destinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label
                                    )
                                },
                                label = { Text(dest.label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = SoftLavender,
                                    indicatorColor = ObsidianElevated,
                                    unselectedIconColor = Color(0xFF8C82A8),
                                    unselectedTextColor = Color(0xFF8C82A8)
                                ),
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = ROUTE_HOME,
                    modifier = Modifier.weight(1f)
                ) {
                    composable(ROUTE_HOME) {
                        HomeScreen(
                            strings = strings,
                            settings = settings,
                            capabilities = capabilities,
                            projects = projects,
                            recentClips = recentClips,
                            onCreateProject = { title, style, ratio ->
                                viewModel.createNewProject(title, style, ratio) {
                                    navigateTo(ROUTE_STUDIO)
                                }
                            },
                            onOpenProject = { projectId, clipId ->
                                viewModel.openProject(projectId, clipId)
                                navigateTo(ROUTE_STUDIO)
                            },
                            onOpenStudio = { navigateTo(ROUTE_STUDIO) },
                            onDeleteProject = { viewModel.deleteProject(it) }
                        )
                    }

                    composable(ROUTE_STUDIO) {
                        StudioScreen(
                            strings = strings,
                            capabilities = capabilities,
                            activeProject = activeProject,
                            selectedClipId = selectedClipId,
                            previewFullStory = previewFullStory,
                            composer = composer,
                            generationState = generationState,
                            onRenameProject = { viewModel.renameActiveProject(it) },
                            onSelectClip = { viewModel.selectClipForPreview(it) },
                            onTogglePreviewFullStory = { viewModel.togglePreviewFullStory(it) },
                            onStartAddNextClip = { viewModel.startAddNextClipFlow(it) },
                            onCancelExtendMode = { viewModel.cancelExtendMode() },
                            onUpdatePrompt = { viewModel.updatePrompt(it) },
                            onUpdateContinuityContext = { viewModel.updateContinuityContext(it) },
                            onUpdateStyle = { viewModel.updateStyle(it) },
                            onUpdateAspectRatio = { viewModel.updateAspectRatio(it) },
                            onUpdateDuration = { viewModel.updateDuration(it) },
                            onPickImageUri = { viewModel.attachPickedReferenceImage(it) },
                            onClearImage = { viewModel.clearReferenceImage() },
                            onGenerate = { viewModel.generateClip() },
                            onCancelGeneration = { viewModel.cancelGeneration() },
                            onRegenerateClip = { viewModel.regenerateClip(it) },
                            onMoveClipEarlier = { viewModel.moveClipEarlier(it) },
                            onMoveClipLater = { viewModel.moveClipLater(it) },
                            onRemoveClip = { viewModel.removeClip(it) },
                            onGoToExport = { navigateTo(ROUTE_EXPORT) }
                        )
                    }

                    composable(ROUTE_EXPORT) {
                        ExportScreen(
                            strings = strings,
                            activeProject = activeProject,
                            exportState = exportState,
                            onExportMp4 = { viewModel.exportFinalMp4() },
                            onSaveToMovies = { viewModel.saveExportedMp4ToMovies() },
                            onOpenStudio = { navigateTo(ROUTE_STUDIO) }
                        )
                    }

                    composable(ROUTE_SETTINGS) {
                        SettingsScreen(
                            strings = strings,
                            settings = settings,
                            providerStatus = providerStatus,
                            isTestingConnection = isTestingConnection,
                            onSelectLanguage = { viewModel.setLanguage(it) },
                            onSaveConfig = { adapter, url, token ->
                                viewModel.saveProviderConfig(adapter, url, token)
                            },
                            onTestConnection = { adapter, url, token ->
                                viewModel.testBackendConnection(adapter, url, token)
                            }
                        )
                    }
                }
            }
        }
    }
}

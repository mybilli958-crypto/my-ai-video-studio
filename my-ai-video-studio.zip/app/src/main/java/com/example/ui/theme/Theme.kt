package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val CinematicDarkColorScheme = darkColorScheme(
    primary = ElectricPurple,
    onPrimary = CrispWhiteText,
    primaryContainer = DeepRoyalPurple,
    onPrimaryContainer = SoftLavender,
    secondary = NeonViolet,
    onSecondary = CrispWhiteText,
    secondaryContainer = ObsidianElevated,
    onSecondaryContainer = SoftLavender,
    tertiary = AiCyan,
    onTertiary = StudioBlack,
    tertiaryContainer = AiCyanContainer,
    onTertiaryContainer = AiCyan,
    background = StudioBlack,
    onBackground = CrispWhiteText,
    surface = ObsidianSurface,
    onSurface = CrispWhiteText,
    surfaceVariant = ObsidianCard,
    onSurfaceVariant = MutedVioletText,
    surfaceContainerLowest = StudioBlack,
    surfaceContainerLow = ObsidianSurface,
    surfaceContainer = ObsidianCard,
    surfaceContainerHigh = ObsidianElevated,
    surfaceContainerHighest = ColorTokens.HighestSurface,
    outline = ObsidianBorder,
    outlineVariant = ColorTokens.SubtleOutline,
    error = ErrorCrimson,
    onError = CrispWhiteText,
    errorContainer = ErrorCrimsonContainer,
    onErrorContainer = ColorTokens.SoftErrorText
)

private object ColorTokens {
    val HighestSurface = androidx.compose.ui.graphics.Color(0xFF2B2246)
    val SubtleOutline = androidx.compose.ui.graphics.Color(0xFF221B3A)
    val SoftErrorText = androidx.compose.ui.graphics.Color(0xFFFCA5A5)
}

val StudioShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun VideoStudioTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CinematicDarkColorScheme,
        typography = StudioTypography,
        shapes = StudioShapes,
        content = content
    )
}

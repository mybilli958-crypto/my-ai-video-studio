package com.example.ui.components

import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.data.local.StudioSettings
import com.example.data.local.VideoClipEntity
import com.example.i18n.AppLanguage
import com.example.i18n.StudioStrings
import com.example.model.AspectRatioOption
import com.example.model.ClipOrigin
import com.example.model.ProviderCapabilities
import com.example.ui.theme.AiCyan
import com.example.ui.theme.AiCyanContainer
import com.example.ui.theme.DemoAmber
import com.example.ui.theme.DemoAmberContainer
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ExportEmerald
import com.example.ui.theme.ExportEmeraldContainer
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.SoftLavender
import com.example.ui.theme.StudioBlack
import java.io.File

@Composable
fun StudioTopHeader(
    title: String,
    strings: StudioStrings,
    settings: StudioSettings,
    capabilities: ProviderCapabilities,
    onToggleLanguage: () -> Unit,
    onBadgeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(ElectricPurple, NeonViolet)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Movie,
                    contentDescription = title,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                ProviderStatusPill(
                    strings = strings,
                    settings = settings,
                    capabilities = capabilities,
                    onClick = onBadgeClick
                )
            }
        }

        Surface(
            onClick = onToggleLanguage,
            shape = RoundedCornerShape(999.dp),
            color = ObsidianCard,
            border = BorderStroke(1.dp, ObsidianBorder),
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .testTag("language_toggle_button")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.Translate,
                    contentDescription = strings.languageSection,
                    tint = SoftLavender,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (settings.language == AppLanguage.ENGLISH) "EN / বাংলা" else "বাংলা / EN",
                    style = MaterialTheme.typography.labelMedium,
                    color = SoftLavender
                )
            }
        }
    }
}

@Composable
fun ProviderStatusPill(
    strings: StudioStrings,
    settings: StudioSettings,
    capabilities: ProviderCapabilities,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDemo = capabilities.isDemo
    val hasBackend = settings.backendBaseUrl.isNotBlank()
    val (bg, fg, icon, label) = when {
        isDemo -> Quad(DemoAmberContainer, DemoAmber, Icons.Filled.Science, strings.demoModeBadge)
        hasBackend -> Quad(ExportEmeraldContainer, ExportEmerald, Icons.Filled.CloudDone, strings.backendConnectedBadge)
        else -> Quad(DemoAmberContainer, DemoAmber, Icons.Filled.CloudOff, strings.backendDisconnectedBadge)
    }

    Surface(
        shape = RoundedCornerShape(999.dp),
        color = bg,
        border = BorderStroke(0.8.dp, fg.copy(alpha = 0.45f)),
        modifier = modifier
            .padding(top = 2.dp)
            .clickable(onClick = onClick)
            .testTag("provider_status_pill")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = fg,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = fg,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@OptIn(UnstableApi::class)
@Composable
fun CinemaVideoMonitor(
    clips: List<VideoClipEntity>,
    selectedClip: VideoClipEntity?,
    playFullSequence: Boolean,
    aspectRatio: AspectRatioOption,
    strings: StudioStrings,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activeClips = remember(clips, selectedClip, playFullSequence) {
        if (playFullSequence && clips.isNotEmpty()) {
            clips
        } else {
            listOfNotNull(selectedClip)
        }
    }

    val validFiles = remember(activeClips) {
        activeClips.mapNotNull { clip ->
            val file = File(clip.videoFilePath)
            if (file.exists() && file.length() > 0L) clip to file else null
        }
    }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ALL
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            exoPlayer.release()
        }
    }

    LaunchedEffect(validFiles) {
        exoPlayer.stop()
        exoPlayer.clearMediaItems()
        if (validFiles.isNotEmpty()) {
            val mediaItems = validFiles.map { (_, file) ->
                MediaItem.fromUri(Uri.fromFile(file))
            }
            exoPlayer.setMediaItems(mediaItems)
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
        }
    }

    val monitorRatio = when (aspectRatio) {
        AspectRatioOption.PORTRAIT_9_16 -> 0.72f
        AspectRatioOption.LANDSCAPE_16_9 -> 16f / 9f
        AspectRatioOption.SQUARE_1_1 -> 1f
    }

    Surface(
        shape = RoundedCornerShape(22.dp),
        color = StudioBlack,
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 210.dp, max = 380.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xFF0A0712), StudioBlack)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (validFiles.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .padding(10.dp)
                            .aspectRatio(monitorRatio)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.Black)
                    ) {
                        AndroidView(
                            factory = { ctx ->
                                PlayerView(ctx).apply {
                                    player = exoPlayer
                                    useController = true
                                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                                    layoutParams = FrameLayout.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.MATCH_PARENT
                                    )
                                }
                            },
                            update = { view ->
                                if (view.player !== exoPlayer) {
                                    view.player = exoPlayer
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .clip(CircleShape)
                                .background(ObsidianElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = strings.previewHeader,
                                tint = SoftLavender,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = strings.emptyTimelineTitle,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = strings.emptyTimelineSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (selectedClip != null) {
                val isDemo = ClipOrigin.fromId(selectedClip.originId) == ClipOrigin.DEMO_SYNTHESIZED
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ObsidianCard)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isDemo) DemoAmberContainer else AiCyanContainer
                        ) {
                            Text(
                                text = if (isDemo) "DEMO" else "AI",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isDemo) DemoAmber else AiCyan,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isDemo) strings.demoClipWarning else "${strings.realAiClipBadge} • ${selectedClip.providerName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isDemo) DemoAmber else AiCyan,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${selectedClip.durationSeconds}s",
                        style = MaterialTheme.typography.labelMedium,
                        color = SoftLavender
                    )
                }
            }
        }
    }
}

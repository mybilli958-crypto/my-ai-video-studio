package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MovieFilter
import androidx.compose.material.icons.filled.Outbox
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.ProjectWithClips
import com.example.data.local.VideoClipEntity
import com.example.i18n.StudioStrings
import com.example.model.AspectRatioOption
import com.example.model.ClipOrigin
import com.example.model.GenerationUiState
import com.example.model.ProviderCapabilities
import com.example.model.VideoStyle
import com.example.ui.components.CinemaVideoMonitor
import com.example.ui.theme.AiCyan
import com.example.ui.theme.AiCyanContainer
import com.example.ui.theme.DemoAmber
import com.example.ui.theme.DemoAmberContainer
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.ErrorCrimsonContainer
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.SoftLavender
import com.example.ui.theme.StudioBlack
import com.example.viewmodel.ComposerState
import java.io.File

@Composable
fun StudioScreen(
    strings: StudioStrings,
    capabilities: ProviderCapabilities,
    activeProject: ProjectWithClips?,
    selectedClipId: Long?,
    previewFullStory: Boolean,
    composer: ComposerState,
    generationState: GenerationUiState,
    onRenameProject: (String) -> Unit,
    onSelectClip: (Long) -> Unit,
    onTogglePreviewFullStory: (Boolean) -> Unit,
    onStartAddNextClip: (VideoClipEntity) -> Unit,
    onCancelExtendMode: () -> Unit,
    onUpdatePrompt: (String) -> Unit,
    onUpdateContinuityContext: (String) -> Unit,
    onUpdateStyle: (VideoStyle) -> Unit,
    onUpdateAspectRatio: (AspectRatioOption) -> Unit,
    onUpdateDuration: (Int) -> Unit,
    onPickImageUri: (Uri) -> Unit,
    onClearImage: () -> Unit,
    onGenerate: () -> Unit,
    onCancelGeneration: () -> Unit,
    onRegenerateClip: (VideoClipEntity) -> Unit,
    onMoveClipEarlier: (VideoClipEntity) -> Unit,
    onMoveClipLater: (VideoClipEntity) -> Unit,
    onRemoveClip: (VideoClipEntity) -> Unit,
    onGoToExport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val clips = activeProject?.orderedClips.orEmpty()
    val selectedClip = clips.firstOrNull { it.id == selectedClipId } ?: clips.lastOrNull()
    val effectiveAspectRatio = if (clips.isNotEmpty() && activeProject != null) {
        AspectRatioOption.fromId(activeProject.project.aspectRatioId)
    } else {
        composer.aspectRatio
    }

    var showRenameDialog by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) onPickImageUri(uri)
        }
    )

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Project title & quick export bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .weight(1f)
                            .clickable(enabled = activeProject != null) { showRenameDialog = true }
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f, fill = false)) {
                            Text(
                                text = activeProject?.project?.title ?: strings.defaultProjectTitle,
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onBackground,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${clips.size} ${strings.clipsCountSuffix} • ${clips.sumOf { it.durationSeconds }}s • ${effectiveAspectRatio.label}",
                                style = MaterialTheme.typography.labelMedium,
                                color = SoftLavender
                            )
                        }
                        if (activeProject != null) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Filled.Edit,
                                contentDescription = strings.projectTitleLabel,
                                tint = SoftLavender,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    if (clips.isNotEmpty()) {
                        OutlinedButton(
                            onClick = onGoToExport,
                            border = BorderStroke(1.dp, ElectricPurple),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("studio_export_shortcut_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Outbox,
                                contentDescription = strings.navExport,
                                tint = SoftLavender,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strings.navExport, color = SoftLavender)
                        }
                    }
                }
            }

            // Cinema Video Preview Area
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (clips.size > 1) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            FilterChip(
                                selected = !previewFullStory,
                                onClick = { onTogglePreviewFullStory(false) },
                                label = { Text(strings.previewSingleClip) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElectricPurple,
                                    selectedLabelColor = Color.White
                                )
                            )
                            FilterChip(
                                selected = previewFullStory,
                                onClick = { onTogglePreviewFullStory(true) },
                                label = { Text(strings.previewAllSequence) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElectricPurple,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.testTag("play_full_story_chip")
                            )
                        }
                    }

                    CinemaVideoMonitor(
                        clips = clips,
                        selectedClip = selectedClip,
                        playFullSequence = previewFullStory,
                        aspectRatio = effectiveAspectRatio,
                        strings = strings
                    )
                }
            }

            // Flow-Style Extend / Add Next Clip Action Bar (shown after generating a clip)
            if (selectedClip != null) {
                item {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = { onStartAddNextClip(clips.lastOrNull() ?: selectedClip) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ObsidianElevated,
                                contentColor = SoftLavender
                            ),
                            border = BorderStroke(1.dp, ElectricPurple.copy(alpha = 0.7f)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("add_next_clip_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.VideoCall,
                                contentDescription = strings.addNextClipBtn,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = strings.addNextClipBtn,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Button(
                            onClick = { onStartAddNextClip(selectedClip) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElectricPurple.copy(alpha = 0.25f),
                                contentColor = Color.White
                            ),
                            border = BorderStroke(1.dp, NeonViolet),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("extend_video_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.FastForward,
                                contentDescription = strings.extendVideoBtn,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = strings.extendVideoBtn,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // Visual Story Timeline
            if (clips.isNotEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = strings.timelineTitle,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            itemsIndexed(clips, key = { _, c -> c.id }) { index, clip ->
                                TimelineClipCard(
                                    clip = clip,
                                    sceneIndex = index + 1,
                                    isSelected = clip.id == selectedClip?.id,
                                    canMoveLeft = index > 0,
                                    canMoveRight = index < clips.lastIndex,
                                    strings = strings,
                                    onSelect = { onSelectClip(clip.id) },
                                    onMoveLeft = { onMoveClipEarlier(clip) },
                                    onMoveRight = { onMoveClipLater(clip) },
                                    onRegenerate = { onRegenerateClip(clip) },
                                    onRemove = { onRemoveClip(clip) }
                                )
                            }

                            item {
                                Surface(
                                    onClick = { clips.lastOrNull()?.let(onStartAddNextClip) },
                                    shape = RoundedCornerShape(16.dp),
                                    color = ObsidianCard,
                                    border = BorderStroke(1.dp, ElectricPurple.copy(alpha = 0.6f)),
                                    modifier = Modifier
                                        .width(126.dp)
                                        .height(176.dp)
                                        .testTag("timeline_add_next_card")
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Add,
                                            contentDescription = strings.addNextClipBtn,
                                            tint = NeonViolet,
                                            modifier = Modifier.size(30.dp)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = strings.addNextClipBtn,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = SoftLavender
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Prompt & Generation Composer Card
            item {
                GenerationComposerCard(
                    strings = strings,
                    capabilities = capabilities,
                    composer = composer,
                    effectiveAspectRatio = effectiveAspectRatio,
                    aspectLocked = clips.isNotEmpty(),
                    generationState = generationState,
                    onCancelExtendMode = onCancelExtendMode,
                    onUpdatePrompt = onUpdatePrompt,
                    onUpdateContinuityContext = onUpdateContinuityContext,
                    onUpdateStyle = onUpdateStyle,
                    onUpdateAspectRatio = onUpdateAspectRatio,
                    onUpdateDuration = onUpdateDuration,
                    onPickImage = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onClearImage = onClearImage,
                    onGenerate = onGenerate,
                    onCancelGeneration = onCancelGeneration
                )
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }

    if (showRenameDialog && activeProject != null) {
        var draftTitle by remember(activeProject.project.title) {
            mutableStateOf(activeProject.project.title)
        }
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            containerColor = ObsidianCard,
            title = { Text(strings.projectTitleLabel) },
            text = {
                OutlinedTextField(
                    value = draftTitle,
                    onValueChange = { draftTitle = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRenameProject(draftTitle)
                        showRenameDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple)
                ) {
                    Text(strings.saveConfigBtn)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text(strings.cancelBtn)
                }
            }
        )
    }
}

@Composable
private fun TimelineClipCard(
    clip: VideoClipEntity,
    sceneIndex: Int,
    isSelected: Boolean,
    canMoveLeft: Boolean,
    canMoveRight: Boolean,
    strings: StudioStrings,
    onSelect: () -> Unit,
    onMoveLeft: () -> Unit,
    onMoveRight: () -> Unit,
    onRegenerate: () -> Unit,
    onRemove: () -> Unit
) {
    val isDemo = ClipOrigin.fromId(clip.originId) == ClipOrigin.DEMO_SYNTHESIZED
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) ObsidianElevated else ObsidianCard,
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) NeonViolet else ObsidianBorder
        ),
        modifier = Modifier
            .width(184.dp)
            .clickable(onClick = onSelect)
            .testTag("timeline_clip_$sceneIndex")
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(86.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(StudioBlack)
            ) {
                if (clip.thumbnailPath.isNotBlank() && File(clip.thumbnailPath).exists()) {
                    AsyncImage(
                        model = File(clip.thumbnailPath),
                        contentDescription = "${strings.sceneLabelPrefix} $sceneIndex",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = StudioBlack.copy(alpha = 0.78f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                ) {
                    Text(
                        text = "${strings.sceneLabelPrefix} $sceneIndex",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isDemo) DemoAmberContainer else AiCyanContainer,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                ) {
                    Text(
                        text = if (isDemo) "DEMO" else "AI",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isDemo) DemoAmber else AiCyan,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = strings.previewSingleClip,
                    tint = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                        .size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = clip.prompt,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${clip.durationSeconds}s • ${clip.continuityModeId}",
                style = MaterialTheme.typography.labelSmall,
                color = SoftLavender,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onMoveLeft,
                    enabled = canMoveLeft,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = strings.moveLeftDesc,
                        tint = if (canMoveLeft) SoftLavender else ObsidianBorder,
                        modifier = Modifier.size(16.dp)
                    )
                }
                IconButton(
                    onClick = onMoveRight,
                    enabled = canMoveRight,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = strings.moveRightDesc,
                        tint = if (canMoveRight) SoftLavender else ObsidianBorder,
                        modifier = Modifier.size(16.dp)
                    )
                }
                IconButton(
                    onClick = onRegenerate,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = strings.regenerateClip,
                        tint = SoftLavender,
                        modifier = Modifier.size(16.dp)
                    )
                }
                IconButton(
                    onClick = onRemove,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeleteOutline,
                        contentDescription = strings.removeClip,
                        tint = ErrorCrimson,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun GenerationComposerCard(
    strings: StudioStrings,
    capabilities: ProviderCapabilities,
    composer: ComposerState,
    effectiveAspectRatio: AspectRatioOption,
    aspectLocked: Boolean,
    generationState: GenerationUiState,
    onCancelExtendMode: () -> Unit,
    onUpdatePrompt: (String) -> Unit,
    onUpdateContinuityContext: (String) -> Unit,
    onUpdateStyle: (VideoStyle) -> Unit,
    onUpdateAspectRatio: (AspectRatioOption) -> Unit,
    onUpdateDuration: (Int) -> Unit,
    onPickImage: () -> Unit,
    onClearImage: () -> Unit,
    onGenerate: () -> Unit,
    onCancelGeneration: () -> Unit
) {
    val isGenerating = generationState is GenerationUiState.Generating

    Surface(
        shape = RoundedCornerShape(22.dp),
        color = ObsidianCard,
        border = BorderStroke(
            1.dp,
            if (composer.isExtendMode) NeonViolet else ObsidianBorder
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Mode header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (composer.isExtendMode) Icons.Filled.FastForward else Icons.Filled.MovieFilter,
                        contentDescription = null,
                        tint = NeonViolet,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (composer.isExtendMode) strings.modeExtendScene else strings.modeNewScene,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                if (composer.isExtendMode) {
                    TextButton(onClick = onCancelExtendMode) {
                        Text(strings.cancelBtn, color = SoftLavender)
                    }
                }
            }

            // Honest continuity notice when extending
            AnimatedVisibility(visible = composer.isExtendMode) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (capabilities.supportsNativeVideoContinuation) AiCyanContainer else DemoAmberContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Info,
                            contentDescription = null,
                            tint = if (capabilities.supportsNativeVideoContinuation) AiCyan else DemoAmber,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (capabilities.supportsNativeVideoContinuation) {
                                strings.continuityHonestNative
                            } else {
                                strings.continuityHonestImageRef
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White
                        )
                    }
                }
            }

            // Prompt input
            OutlinedTextField(
                value = composer.prompt,
                onValueChange = onUpdatePrompt,
                label = {
                    Text(
                        if (composer.isExtendMode) strings.nextScenePromptLabel else strings.promptLabel
                    )
                },
                placeholder = {
                    Text(
                        if (composer.isExtendMode) strings.nextScenePromptHint else strings.promptHint
                    )
                },
                minLines = 3,
                maxLines = 5,
                enabled = !isGenerating,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("scene_prompt_input")
            )

            // Continuity context lock
            OutlinedTextField(
                value = composer.continuityContext,
                onValueChange = onUpdateContinuityContext,
                label = { Text(strings.continuityContextLabel) },
                placeholder = { Text(strings.continuityContextHint) },
                minLines = 1,
                maxLines = 3,
                enabled = !isGenerating,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("continuity_context_input")
            )

            // Image-to-Video / Reference Frame picker
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = strings.referenceImageLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (!composer.referenceImagePath.isNullOrBlank() && File(composer.referenceImagePath).exists()) {
                        AsyncImage(
                            model = File(composer.referenceImagePath),
                            contentDescription = strings.referenceImageLabel,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(10.dp))
                        )
                    }
                    OutlinedButton(
                        onClick = onPickImage,
                        enabled = !isGenerating,
                        border = BorderStroke(1.dp, ObsidianBorder),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("pick_reference_image_button")
                    ) {
                        Icon(Icons.Filled.Image, contentDescription = strings.pickImageBtn, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.pickImageBtn)
                    }
                    if (!composer.referenceImagePath.isNullOrBlank()) {
                        IconButton(
                            onClick = onClearImage,
                            enabled = !isGenerating,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Filled.Close, contentDescription = strings.clearImageBtn, tint = SoftLavender)
                        }
                    }
                }
                if (composer.isExtendMode && !composer.referenceImagePath.isNullOrBlank()) {
                    Text(
                        text = strings.previousFrameLoaded,
                        style = MaterialTheme.typography.bodySmall,
                        color = SoftLavender
                    )
                }
            }

            // Style Selector: A. Realistic Cinematic / B. 3D Cartoon
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(strings.styleLabel, style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = composer.style == VideoStyle.REALISTIC_CINEMATIC,
                        onClick = { onUpdateStyle(VideoStyle.REALISTIC_CINEMATIC) },
                        label = { Text("A. ${strings.styleRealisticCinematic}") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricPurple,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("style_realistic_chip")
                    )
                    FilterChip(
                        selected = composer.style == VideoStyle.CARTOON_3D,
                        onClick = { onUpdateStyle(VideoStyle.CARTOON_3D) },
                        label = { Text("B. ${strings.style3dCartoon}") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricPurple,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("style_3d_cartoon_chip")
                    )
                }
            }

            // Aspect Ratio Selector
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(strings.aspectRatioLabel, style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    capabilities.supportedAspectRatios.forEach { ratio ->
                        FilterChip(
                            selected = effectiveAspectRatio == ratio,
                            enabled = !aspectLocked && !isGenerating,
                            onClick = { onUpdateAspectRatio(ratio) },
                            label = { Text(ratio.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricPurple,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("aspect_chip_${ratio.id}")
                        )
                    }
                }
                if (aspectLocked) {
                    Text(
                        text = strings.aspectLockedNotice,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Clip Duration Selector (from active provider capabilities)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(strings.durationLabel, style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    capabilities.supportedDurationsSeconds.forEach { sec ->
                        FilterChip(
                            selected = composer.durationSeconds == sec,
                            enabled = !isGenerating,
                            onClick = { onUpdateDuration(sec) },
                            label = { Text("${sec}s") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricPurple,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("duration_chip_$sec")
                        )
                    }
                }
            }

            // Error State
            if (generationState is GenerationUiState.Error) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = ErrorCrimsonContainer,
                    border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ErrorOutline,
                            contentDescription = null,
                            tint = ErrorCrimson,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = generationState.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White,
                                fontWeight = FontWeight.Medium
                            )
                            if (!generationState.detail.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = generationState.detail,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFFFCA5A5)
                                )
                            }
                        }
                    }
                }
            }

            // Progress State
            if (generationState is GenerationUiState.Generating) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = generationState.statusLabel,
                            style = MaterialTheme.typography.bodySmall,
                            color = SoftLavender
                        )
                        Text(
                            text = "${(generationState.progress * 100).toInt()}%",
                            style = MaterialTheme.typography.labelMedium,
                            color = SoftLavender
                        )
                    }
                    LinearProgressIndicator(
                        progress = { generationState.progress.coerceIn(0f, 1f) },
                        color = NeonViolet,
                        trackColor = ObsidianElevated,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(999.dp))
                    )
                }
            }

            // Purple Generate Video Button
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = onGenerate,
                    enabled = !isGenerating,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricPurple,
                        contentColor = Color.White,
                        disabledContainerColor = ElectricPurple.copy(alpha = 0.45f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(54.dp)
                        .testTag("generate_video_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = strings.generateVideoBtn,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (composer.isExtendMode) {
                            strings.generateNextClipBtn
                        } else {
                            strings.generateVideoBtn
                        },
                        style = MaterialTheme.typography.labelLarge
                    )
                }

                if (isGenerating) {
                    OutlinedButton(
                        onClick = onCancelGeneration,
                        border = BorderStroke(1.dp, ErrorCrimson),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .height(54.dp)
                            .testTag("cancel_generation_button")
                    ) {
                        Text(strings.cancelBtn, color = ErrorCrimson)
                    }
                }
            }
        }
    }
}

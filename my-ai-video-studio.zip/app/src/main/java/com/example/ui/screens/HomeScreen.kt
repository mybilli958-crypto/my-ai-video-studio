package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.local.ProjectWithClips
import com.example.data.local.StudioSettings
import com.example.data.local.VideoClipEntity
import com.example.i18n.StudioStrings
import com.example.model.AspectRatioOption
import com.example.model.ClipOrigin
import com.example.model.ProviderCapabilities
import com.example.model.VideoStyle
import com.example.ui.theme.AiCyan
import com.example.ui.theme.AiCyanContainer
import com.example.ui.theme.DemoAmber
import com.example.ui.theme.DemoAmberContainer
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.SoftLavender
import com.example.ui.theme.StudioBlack
import java.io.File
import java.text.DateFormat
import java.util.Date

@Composable
fun HomeScreen(
    strings: StudioStrings,
    settings: StudioSettings,
    capabilities: ProviderCapabilities,
    projects: List<ProjectWithClips>,
    recentClips: List<VideoClipEntity>,
    onCreateProject: (String, VideoStyle, AspectRatioOption) -> Unit,
    onOpenProject: (Long, Long?) -> Unit,
    onOpenStudio: () -> Unit,
    onDeleteProject: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var showNewDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                HeroStudioBanner(
                    strings = strings,
                    isDemo = capabilities.isDemo,
                    hasProjects = projects.isNotEmpty(),
                    onNewProjectClick = { showNewDialog = true },
                    onOpenStudioClick = onOpenStudio
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.recentProjectsTitle,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${projects.size}",
                        style = MaterialTheme.typography.labelMedium,
                        color = SoftLavender
                    )
                }
            }

            if (projects.isEmpty()) {
                item {
                    EmptyHomeCard(
                        title = strings.noProjectsTitle,
                        subtitle = strings.noProjectsSubtitle,
                        actionLabel = strings.newProjectCta,
                        onAction = { showNewDialog = true }
                    )
                }
            } else {
                items(projects, key = { it.project.id }) { item ->
                    ProjectHistoryCard(
                        item = item,
                        strings = strings,
                        onOpen = { onOpenProject(item.project.id, null) },
                        onDelete = { onDeleteProject(item.project.id) }
                    )
                }
            }

            item {
                Text(
                    text = strings.recentClipsTitle,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            if (recentClips.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = ObsidianCard,
                        border = BorderStroke(1.dp, ObsidianBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = strings.noClipsTitle,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = strings.noClipsSubtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(recentClips, key = { it.id }) { clip ->
                            RecentClipMiniCard(
                                clip = clip,
                                strings = strings,
                                onClick = { onOpenProject(clip.projectId, clip.id) }
                            )
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }

    if (showNewDialog) {
        NewProjectDialog(
            strings = strings,
            supportedAspects = capabilities.supportedAspectRatios,
            onDismiss = { showNewDialog = false },
            onConfirm = { title, style, ratio ->
                showNewDialog = false
                onCreateProject(title, style, ratio)
            }
        )
    }
}

@Composable
private fun HeroStudioBanner(
    strings: StudioStrings,
    isDemo: Boolean,
    hasProjects: Boolean,
    onNewProjectClick: () -> Unit,
    onOpenStudioClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = ObsidianCard,
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.img_studio_hero),
                contentDescription = strings.heroHeadline,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .matchParentSize()
                    .clip(RoundedCornerShape(24.dp))
            )
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                StudioBlack.copy(alpha = 0.55f),
                                StudioBlack.copy(alpha = 0.92f)
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier.padding(20.dp)
            ) {
                Text(
                    text = strings.heroHeadline,
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isDemo) strings.heroSubtitleDemo else strings.heroSubtitleBackend,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFD8D0EC)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = onNewProjectClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricPurple,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("new_project_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = strings.newProjectCta,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = strings.newProjectCta,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    if (hasProjects) {
                        OutlinedButton(
                            onClick = onOpenStudioClick,
                            border = BorderStroke(1.dp, SoftLavender.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .height(50.dp)
                                .testTag("open_active_studio_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.MovieCreation,
                                contentDescription = strings.quickCreateCta,
                                tint = SoftLavender,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyHomeCard(
    title: String,
    subtitle: String,
    actionLabel: String,
    onAction: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = ObsidianCard,
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_storyboard),
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(145.dp)
                    .clip(RoundedCornerShape(14.dp))
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("empty_new_project_button")
            ) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = actionLabel, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(actionLabel)
            }
        }
    }
}

@Composable
private fun ProjectHistoryCard(
    item: ProjectWithClips,
    strings: StudioStrings,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    val ordered = item.orderedClips
    val firstThumb = ordered.firstOrNull()?.thumbnailPath
    val totalSec = ordered.sumOf { it.durationSeconds }
    val dateLabel = remember(item.project.updatedAt) {
        DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
            .format(Date(item.project.updatedAt))
    }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = ObsidianCard,
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .testTag("project_card_${item.project.id}")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ObsidianElevated),
                contentAlignment = Alignment.Center
            ) {
                if (!firstThumb.isNullOrBlank() && File(firstThumb).exists()) {
                    AsyncImage(
                        model = File(firstThumb),
                        contentDescription = item.project.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.MovieCreation,
                        contentDescription = item.project.title,
                        tint = SoftLavender
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.project.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    MetaTag(text = "${ordered.size} ${strings.clipsCountSuffix}")
                    MetaTag(text = "${totalSec}s")
                    MetaTag(text = item.project.aspectRatioId)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = dateLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(
                    imageVector = Icons.Filled.DeleteOutline,
                    contentDescription = strings.deleteProject,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = strings.continueProject,
                tint = SoftLavender,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun RecentClipMiniCard(
    clip: VideoClipEntity,
    strings: StudioStrings,
    onClick: () -> Unit
) {
    val isDemo = ClipOrigin.fromId(clip.originId) == ClipOrigin.DEMO_SYNTHESIZED
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = ObsidianCard,
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = Modifier
            .width(172.dp)
            .clickable(onClick = onClick)
            .testTag("recent_clip_${clip.id}")
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(104.dp)
                    .background(ObsidianElevated)
            ) {
                if (clip.thumbnailPath.isNotBlank() && File(clip.thumbnailPath).exists()) {
                    AsyncImage(
                        model = File(clip.thumbnailPath),
                        contentDescription = clip.prompt,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(36.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(StudioBlack.copy(alpha = 0.72f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = clip.prompt,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isDemo) DemoAmberContainer else AiCyanContainer,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                ) {
                    Text(
                        text = if (isDemo) "DEMO" else "AI",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isDemo) DemoAmber else AiCyan,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = clip.prompt,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${clip.durationSeconds}s • ${clip.aspectRatioId}",
                    style = MaterialTheme.typography.labelSmall,
                    color = SoftLavender
                )
            }
        }
    }
}

@Composable
private fun MetaTag(text: String) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = ObsidianElevated
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = SoftLavender,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun NewProjectDialog(
    strings: StudioStrings,
    supportedAspects: List<AspectRatioOption>,
    onDismiss: () -> Unit,
    onConfirm: (String, VideoStyle, AspectRatioOption) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var style by remember { mutableStateOf(VideoStyle.REALISTIC_CINEMATIC) }
    var ratio by remember {
        mutableStateOf(supportedAspects.firstOrNull() ?: AspectRatioOption.PORTRAIT_9_16)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ObsidianCard,
        title = {
            Text(strings.newStoryDialogTitle, style = MaterialTheme.typography.titleLarge)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(strings.projectTitleLabel) },
                    placeholder = { Text(strings.defaultProjectTitle) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_project_title_input")
                )

                Text(strings.styleLabel, style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = style == VideoStyle.REALISTIC_CINEMATIC,
                        onClick = { style = VideoStyle.REALISTIC_CINEMATIC },
                        label = { Text(strings.styleRealisticCinematic) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricPurple,
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = style == VideoStyle.CARTOON_3D,
                        onClick = { style = VideoStyle.CARTOON_3D },
                        label = { Text(strings.style3dCartoon) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricPurple,
                            selectedLabelColor = Color.White
                        )
                    )
                }

                Text(strings.aspectRatioLabel, style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    supportedAspects.forEach { option ->
                        FilterChip(
                            selected = ratio == option,
                            onClick = { ratio = option },
                            label = { Text(option.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricPurple,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(title, style, ratio) },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                modifier = Modifier.testTag("confirm_create_project_button")
            ) {
                Text(strings.createBtn)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancelBtn)
            }
        }
    )
}

package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.data.local.ProjectWithClips
import com.example.i18n.StudioStrings
import com.example.model.AspectRatioOption
import com.example.model.ClipOrigin
import com.example.model.ExportUiState
import com.example.ui.components.CinemaVideoMonitor
import com.example.ui.theme.AiCyan
import com.example.ui.theme.AiCyanContainer
import com.example.ui.theme.DemoAmber
import com.example.ui.theme.DemoAmberContainer
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.ErrorCrimsonContainer
import com.example.ui.theme.ExportEmerald
import com.example.ui.theme.ExportEmeraldContainer
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.SoftLavender
import com.example.ui.theme.StudioBlack
import java.io.File

@Composable
fun ExportScreen(
    strings: StudioStrings,
    activeProject: ProjectWithClips?,
    exportState: ExportUiState,
    onExportMp4: () -> Unit,
    onSaveToMovies: () -> Unit,
    onOpenStudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clips = activeProject?.orderedClips.orEmpty()
    val aspectRatio = activeProject?.let { AspectRatioOption.fromId(it.project.aspectRatioId) }
        ?: AspectRatioOption.PORTRAIT_9_16

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = strings.exportTitle,
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = strings.exportSubtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (clips.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = ObsidianCard,
                        border = BorderStroke(1.dp, ObsidianBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Movie,
                                contentDescription = strings.exportEmptyTitle,
                                tint = SoftLavender,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = strings.exportEmptyTitle,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = strings.exportEmptySubtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = onOpenStudio,
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple)
                            ) {
                                Text(strings.quickCreateCta)
                            }
                        }
                    }
                }
            } else {
                item {
                    CinemaVideoMonitor(
                        clips = clips,
                        selectedClip = clips.firstOrNull(),
                        playFullSequence = true,
                        aspectRatio = aspectRatio,
                        strings = strings
                    )
                }

                // Export Action & Status Card
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = ObsidianCard,
                        border = BorderStroke(1.dp, ObsidianBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = activeProject?.project?.title ?: strings.defaultProjectTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${clips.size} ${strings.clipsCountSuffix} • ${clips.sumOf { it.durationSeconds }}s",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = SoftLavender
                                )
                            }

                            val isExporting = exportState is ExportUiState.Exporting
                            Button(
                                onClick = onExportMp4,
                                enabled = !isExporting,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ElectricPurple,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("join_export_mp4_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.VideoFile,
                                    contentDescription = strings.joinAndExportBtn,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(strings.joinAndExportBtn)
                            }

                            if (exportState is ExportUiState.Exporting) {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = strings.exportingProgressPrefix,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = SoftLavender
                                        )
                                        Text(
                                            text = "${exportState.progressPercent}%",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = SoftLavender
                                        )
                                    }
                                    LinearProgressIndicator(
                                        progress = { exportState.progressPercent / 100f },
                                        color = NeonViolet,
                                        trackColor = ObsidianElevated,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(8.dp)
                                            .clip(RoundedCornerShape(999.dp))
                                    )
                                }
                            }

                            if (exportState is ExportUiState.Failed) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = ErrorCrimsonContainer,
                                    border = BorderStroke(1.dp, ErrorCrimson.copy(alpha = 0.6f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.ErrorOutline,
                                            contentDescription = null,
                                            tint = ErrorCrimson,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = strings.exportErrorTitle,
                                                style = MaterialTheme.typography.labelLarge,
                                                color = Color.White
                                            )
                                            Text(
                                                text = exportState.errorMessage,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color(0xFFFCA5A5)
                                            )
                                        }
                                    }
                                }
                            }

                            if (exportState is ExportUiState.Completed && File(exportState.outputFilePath).exists()) {
                                val sizeMb = String.format("%.2f MB", exportState.fileSizeBytes / (1024f * 1024f))
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = ExportEmeraldContainer,
                                    border = BorderStroke(1.dp, ExportEmerald.copy(alpha = 0.55f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Filled.CheckCircle,
                                                contentDescription = null,
                                                tint = ExportEmerald,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(
                                                    text = strings.exportSuccessTitle,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = "${exportState.clipCount} ${strings.clipsCountSuffix} • $sizeMb • MP4",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    color = ExportEmerald
                                                )
                                            }
                                        }

                                        if (exportState.savedToGalleryUri != null) {
                                            Text(
                                                text = strings.savedToMoviesMsg,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color.White
                                            )
                                        }

                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Button(
                                                onClick = onSaveToMovies,
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = ExportEmerald,
                                                    contentColor = StudioBlack
                                                ),
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(48.dp)
                                                    .testTag("download_mp4_button")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.Download,
                                                    contentDescription = strings.saveToDeviceBtn,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = strings.saveToDeviceBtn,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }

                                            OutlinedButton(
                                                onClick = {
                                                    val file = File(exportState.outputFilePath)
                                                    val shareUri = FileProvider.getUriForFile(
                                                        context,
                                                        "${context.packageName}.fileprovider",
                                                        file
                                                    )
                                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                        type = "video/mp4"
                                                        putExtra(Intent.EXTRA_STREAM, shareUri)
                                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                    }
                                                    context.startActivity(
                                                        Intent.createChooser(shareIntent, strings.shareVideoBtn)
                                                    )
                                                },
                                                border = BorderStroke(1.dp, ExportEmerald),
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier
                                                    .height(48.dp)
                                                    .testTag("share_mp4_button")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.Share,
                                                    contentDescription = strings.shareVideoBtn,
                                                    tint = ExportEmerald,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Sequence breakdown
                itemsIndexed(clips, key = { _, c -> c.id }) { idx, clip ->
                    val isDemo = ClipOrigin.fromId(clip.originId) == ClipOrigin.DEMO_SYNTHESIZED
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = ObsidianCard,
                        border = BorderStroke(1.dp, ObsidianBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(ObsidianElevated)
                            ) {
                                if (clip.thumbnailPath.isNotBlank() && File(clip.thumbnailPath).exists()) {
                                    AsyncImage(
                                        model = File(clip.thumbnailPath),
                                        contentDescription = "${strings.sceneLabelPrefix} ${idx + 1}",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${strings.sceneLabelPrefix} ${idx + 1} • ${clip.durationSeconds}s",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = SoftLavender
                                )
                                Text(
                                    text = clip.prompt,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isDemo) DemoAmberContainer else AiCyanContainer
                            ) {
                                Text(
                                    text = if (isDemo) "DEMO" else "AI",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isDemo) DemoAmber else AiCyan,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

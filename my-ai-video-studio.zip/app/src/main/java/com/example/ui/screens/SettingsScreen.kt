package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.StudioSettings
import com.example.i18n.AppLanguage
import com.example.i18n.StudioStrings
import com.example.model.ProviderAdapterId
import com.example.model.ProviderStatus
import com.example.provider.ProviderCatalog
import com.example.ui.theme.AiCyan
import com.example.ui.theme.DemoAmber
import com.example.ui.theme.DemoAmberContainer
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.ErrorCrimsonContainer
import com.example.ui.theme.ExportEmerald
import com.example.ui.theme.ExportEmeraldContainer
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.SoftLavender

@Composable
fun SettingsScreen(
    strings: StudioStrings,
    settings: StudioSettings,
    providerStatus: ProviderStatus?,
    isTestingConnection: Boolean,
    onSelectLanguage: (AppLanguage) -> Unit,
    onSaveConfig: (ProviderAdapterId, String, String) -> Unit,
    onTestConnection: (ProviderAdapterId, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var draftAdapterId by remember(settings.selectedAdapterId) {
        mutableStateOf(settings.selectedAdapterId)
    }
    var draftBackendUrl by remember(settings.backendBaseUrl) {
        mutableStateOf(settings.backendBaseUrl)
    }
    var draftBearerToken by remember(settings.backendClientToken) {
        mutableStateOf(settings.backendClientToken)
    }

    val draftCapabilities = remember(draftAdapterId) {
        ProviderCatalog.capabilitiesFor(draftAdapterId)
    }
    val isBengali = settings.language == AppLanguage.BENGALI

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = strings.settingsTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            // Interface Language Section
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = ObsidianCard,
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Translate,
                                contentDescription = strings.languageSection,
                                tint = SoftLavender,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = strings.languageSection,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FilterChip(
                                selected = settings.language == AppLanguage.ENGLISH,
                                onClick = { onSelectLanguage(AppLanguage.ENGLISH) },
                                label = { Text("English") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElectricPurple,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.testTag("lang_en_chip")
                            )
                            FilterChip(
                                selected = settings.language == AppLanguage.BENGALI,
                                onClick = { onSelectLanguage(AppLanguage.BENGALI) },
                                label = { Text("বাংলা (Bengali)") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElectricPurple,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.testTag("lang_bn_chip")
                            )
                        }
                    }
                }
            }

            // Provider Adapter Selection
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = ObsidianCard,
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.CloudQueue,
                                contentDescription = strings.providerSection,
                                tint = SoftLavender,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = strings.providerSection,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }

                        ProviderAdapterId.entries.forEach { adapterId ->
                            val caps = ProviderCatalog.capabilitiesFor(adapterId)
                            val selected = draftAdapterId == adapterId
                            Surface(
                                onClick = { draftAdapterId = adapterId },
                                shape = RoundedCornerShape(14.dp),
                                color = if (selected) ObsidianElevated else Color.Transparent,
                                border = BorderStroke(
                                    1.dp,
                                    if (selected) ElectricPurple else ObsidianBorder
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("adapter_option_${adapterId.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = selected,
                                        onClick = { draftAdapterId = adapterId },
                                        colors = RadioButtonDefaults.colors(selectedColor = ElectricPurple)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = caps.displayName,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = if (isBengali) caps.quotaSummaryBn else caps.quotaSummaryEn,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    if (caps.isDemo) {
                                        Icon(
                                            imageVector = Icons.Filled.Science,
                                            contentDescription = null,
                                            tint = DemoAmber,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }

                        if (draftCapabilities.requiresBackendUrl) {
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = draftBackendUrl,
                                onValueChange = { draftBackendUrl = it },
                                label = { Text(strings.backendUrlLabel) },
                                placeholder = { Text(strings.backendUrlHint) },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("backend_url_input")
                            )
                            OutlinedTextField(
                                value = draftBearerToken,
                                onValueChange = { draftBearerToken = it },
                                label = { Text(strings.backendTokenLabel) },
                                placeholder = { Text(strings.backendTokenHint) },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("backend_token_input")
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = {
                                    onSaveConfig(draftAdapterId, draftBackendUrl, draftBearerToken)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("save_provider_config_button")
                            ) {
                                Text(strings.saveConfigBtn)
                            }

                            OutlinedButton(
                                onClick = {
                                    onTestConnection(draftAdapterId, draftBackendUrl, draftBearerToken)
                                },
                                enabled = !isTestingConnection,
                                border = BorderStroke(1.dp, SoftLavender.copy(alpha = 0.6f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("test_backend_button")
                            ) {
                                if (isTestingConnection) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Text(strings.testConnectionBtn, color = SoftLavender)
                                }
                            }
                        }

                        if (providerStatus != null) {
                            val ok = providerStatus.isReachable
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = when {
                                    providerStatus.isDemo -> DemoAmberContainer
                                    ok -> ExportEmeraldContainer
                                    else -> ErrorCrimsonContainer
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Icon(
                                        imageVector = if (ok) Icons.Filled.CheckCircle else Icons.Filled.ErrorOutline,
                                        contentDescription = null,
                                        tint = when {
                                            providerStatus.isDemo -> DemoAmber
                                            ok -> ExportEmerald
                                            else -> ErrorCrimson
                                        },
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = providerStatus.providerLabel,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = Color.White
                                        )
                                        Text(
                                            text = providerStatus.detailMessage,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.White.copy(alpha = 0.9f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Selected Adapter Capabilities Matrix
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = ObsidianCard,
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "${strings.adapterCapabilitiesTitle}: ${draftCapabilities.displayName}",
                            style = MaterialTheme.typography.titleMedium
                        )
                        CapabilityRow(
                            label = strings.textToVideoCap,
                            value = if (draftCapabilities.supportsTextToVideo) strings.supported else strings.unsupported,
                            highlight = draftCapabilities.supportsTextToVideo
                        )
                        CapabilityRow(
                            label = strings.imageToVideoCap,
                            value = if (draftCapabilities.supportsImageToVideo) strings.supported else strings.unsupported,
                            highlight = draftCapabilities.supportsImageToVideo
                        )
                        CapabilityRow(
                            label = strings.nativeExtendCap,
                            value = if (draftCapabilities.supportsNativeVideoContinuation) {
                                strings.supported
                            } else {
                                "${strings.unsupported} (${strings.imageRefFallbackNote})"
                            },
                            highlight = draftCapabilities.supportsNativeVideoContinuation
                        )
                        CapabilityRow(
                            label = strings.supportedDurationsCap,
                            value = draftCapabilities.supportedDurationsSeconds.joinToString(", ") { "${it}s" },
                            highlight = true
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = strings.quotasTitle,
                            style = MaterialTheme.typography.labelLarge,
                            color = SoftLavender
                        )
                        Text(
                            text = if (isBengali) draftCapabilities.limitationsBn else draftCapabilities.limitationsEn,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Security & External Provider Explanation Cards
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = ObsidianCard,
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = strings.securityNoticeTitle,
                                tint = AiCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = strings.securityNoticeTitle,
                                style = MaterialTheme.typography.titleSmall,
                                color = AiCyan
                            )
                        }
                        Text(
                            text = strings.securityNoticeBody,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Info,
                                contentDescription = strings.externalRequiredTitle,
                                tint = DemoAmber,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = strings.externalRequiredTitle,
                                style = MaterialTheme.typography.titleSmall,
                                color = DemoAmber
                            )
                        }
                        Text(
                            text = strings.externalRequiredBody,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun CapabilityRow(
    label: String,
    value: String,
    highlight: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = if (highlight) ExportEmerald else DemoAmber
        )
    }
}

package com.example.media

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.example.data.local.VideoClipEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

sealed interface InternalExportEvent {
    data class Progress(val percent: Int) : InternalExportEvent
    data class Success(val outputPath: String, val sizeBytes: Long) : InternalExportEvent
    data class Error(val message: String) : InternalExportEvent
}

object VideoExportManager {

    @OptIn(UnstableApi::class)
    fun joinClipsToMp4(
        context: Context,
        projectId: Long,
        clips: List<VideoClipEntity>
    ): Flow<InternalExportEvent> = callbackFlow {
        val mainHandler = Handler(Looper.getMainLooper())
        val validClips = clips.filter { File(it.videoFilePath).let { f -> f.exists() && f.length() > 0L } }
        if (validClips.isEmpty()) {
            trySend(InternalExportEvent.Error("No valid MP4 clip files found to export."))
            close()
            return@callbackFlow
        }

        val exportDir = File(context.filesDir, "exports").apply { mkdirs() }
        val outputFile = File(exportDir, "story_${projectId}_${System.currentTimeMillis()}.mp4")
        if (outputFile.exists()) outputFile.delete()

        var transformer: Transformer? = null
        var pollingActive = true

        mainHandler.post {
            try {
                val editedItems = validClips.map { clip ->
                    val mediaItem = MediaItem.fromUri(Uri.fromFile(File(clip.videoFilePath)))
                    EditedMediaItem.Builder(mediaItem).build()
                }
                val sequence = EditedMediaItemSequence.withVideoFrom(editedItems)
                val composition = Composition.Builder(sequence).build()

                val listener = object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        pollingActive = false
                        val size = if (outputFile.exists()) outputFile.length() else 0L
                        if (size > 0L) {
                            trySend(InternalExportEvent.Success(outputFile.absolutePath, size))
                        } else {
                            trySend(InternalExportEvent.Error("Export finished but output MP4 file is empty."))
                        }
                        close()
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        pollingActive = false
                        if (outputFile.exists()) outputFile.delete()
                        trySend(
                            InternalExportEvent.Error(
                                exportException.localizedMessage
                                    ?: "Media3 Transformer failed to join clips (code ${exportException.errorCode})."
                            )
                        )
                        close()
                    }
                }

                val built = Transformer.Builder(context)
                    .addListener(listener)
                    .build()
                transformer = built

                built.start(composition, outputFile.absolutePath)

                val progressHolder = ProgressHolder()
                val progressRunnable = object : Runnable {
                    override fun run() {
                        if (!pollingActive) return
                        val state = built.getProgress(progressHolder)
                        if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                            trySend(InternalExportEvent.Progress(progressHolder.progress.coerceIn(0, 99)))
                        }
                        if (state != Transformer.PROGRESS_STATE_NOT_STARTED && pollingActive) {
                            mainHandler.postDelayed(this, 250L)
                        }
                    }
                }
                mainHandler.postDelayed(progressRunnable, 200L)
            } catch (e: Exception) {
                pollingActive = false
                trySend(InternalExportEvent.Error(e.localizedMessage ?: "Failed to start MP4 export."))
                close()
            }
        }

        awaitClose {
            pollingActive = false
            mainHandler.post {
                runCatching { transformer?.cancel() }
            }
        }
    }

    suspend fun saveMp4ToMovies(
        context: Context,
        sourcePath: String,
        displayTitle: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val sourceFile = File(sourcePath)
        if (!sourceFile.exists() || sourceFile.length() == 0L) {
            return@withContext Result.failure(IllegalStateException("Exported MP4 file is missing."))
        }

        val cleanName = displayTitle
            .replace(Regex("[^a-zA-Z0-9_-]"), "_")
            .take(36)
            .ifBlank { "MyAIVideoStudio" }
        val fileName = "${cleanName}_${System.currentTimeMillis()}.mp4"

        return@withContext try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(
                        MediaStore.Video.Media.RELATIVE_PATH,
                        "${Environment.DIRECTORY_MOVIES}/MyAIVideoStudio"
                    )
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return@withContext Result.failure(
                        IllegalStateException("Unable to create MediaStore entry.")
                    )

                resolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(sourceFile).use { input ->
                        input.copyTo(out)
                    }
                } ?: return@withContext Result.failure(
                    IllegalStateException("Failed to open destination stream.")
                )

                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                Result.success(uri.toString())
            } else {
                @Suppress("DEPRECATION")
                val moviesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                val appDir = File(moviesDir, "MyAIVideoStudio").apply { mkdirs() }
                val destFile = File(appDir, fileName)
                FileInputStream(sourceFile).use { input ->
                    FileOutputStream(destFile).use { out ->
                        input.copyTo(out)
                    }
                }
                MediaScannerConnection.scanFile(context, arrayOf(destFile.absolutePath), arrayOf("video/mp4"), null)
                Result.success(destFile.absolutePath)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

package com.example.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object VideoFrameExtractor {

    suspend fun extractLastFrame(
        context: Context,
        videoFilePath: String,
        outputTag: String
    ): String? = withContext(Dispatchers.IO) {
        val videoFile = File(videoFilePath)
        if (!videoFile.exists() || videoFile.length() == 0L) return@withContext null

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(videoFile.absolutePath)
            val durationMs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: 0L

            val targetTimeUs = ((durationMs - 80L).coerceAtLeast(0L)) * 1000L
            val bitmap = retriever.getFrameAtTime(
                targetTimeUs,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC
            ) ?: retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: return@withContext null

            val framesDir = File(context.filesDir, "frames").apply { mkdirs() }
            val outFile = File(framesDir, "last_frame_${outputTag}_${System.currentTimeMillis()}.jpg")
            FileOutputStream(outFile).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos)
            }
            bitmap.recycle()
            outFile.absolutePath
        } catch (_: Exception) {
            null
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }

    suspend fun copyUriToInternalRef(
        context: Context,
        uri: Uri
    ): String? = withContext(Dispatchers.IO) {
        try {
            val refsDir = File(context.filesDir, "refs").apply { mkdirs() }
            val outFile = File(refsDir, "ref_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                val decoded = BitmapFactory.decodeStream(input) ?: return@withContext null
                val scaled = scaleDownKeepingAspect(decoded, 1280)
                FileOutputStream(outFile).use { fos ->
                    scaled.compress(Bitmap.CompressFormat.JPEG, 90, fos)
                }
                if (scaled !== decoded) decoded.recycle()
                scaled.recycle()
                outFile.absolutePath
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun scaleDownKeepingAspect(bitmap: Bitmap, maxDim: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= maxDim && h <= maxDim) return bitmap
        val ratio = minOf(maxDim.toFloat() / w, maxDim.toFloat() / h)
        val nw = (w * ratio).toInt().coerceAtLeast(1)
        val nh = (h * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, nw, nh, true)
    }
}

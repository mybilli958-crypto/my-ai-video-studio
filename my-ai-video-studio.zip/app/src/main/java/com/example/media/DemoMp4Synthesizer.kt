package com.example.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import com.example.model.AspectRatioOption
import com.example.model.VideoStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.coroutineContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

data class SynthesizedDemoClip(
    val videoFilePath: String,
    val thumbnailPath: String
)

object DemoMp4Synthesizer {

    private const val MIME_TYPE = MediaFormat.MIMETYPE_VIDEO_AVC
    private const val FPS = 24
    private const val BIT_RATE = 1_600_000
    private const val I_FRAME_INTERVAL = 1

    suspend fun synthesizeClip(
        context: Context,
        sceneNumber: Int,
        prompt: String,
        continuityContext: String,
        style: VideoStyle,
        aspectRatio: AspectRatioOption,
        durationSeconds: Int,
        referenceImagePath: String?,
        onProgress: (Float) -> Unit
    ): SynthesizedDemoClip = withContext(Dispatchers.IO) {
        val videosDir = File(context.filesDir, "videos").apply { mkdirs() }
        val thumbsDir = File(context.filesDir, "thumbs").apply { mkdirs() }
        val stamp = System.currentTimeMillis()
        val videoFile = File(videosDir, "demo_scene_${sceneNumber}_$stamp.mp4")
        val thumbFile = File(thumbsDir, "thumb_scene_${sceneNumber}_$stamp.jpg")

        val width = aspectRatio.encodeWidth
        val height = aspectRatio.encodeHeight
        val totalFrames = (durationSeconds.coerceIn(2, 12)) * FPS
        val frameDurationUs = 1_000_000L / FPS

        val refBitmap: Bitmap? = referenceImagePath?.let { path ->
            runCatching { BitmapFactory.decodeFile(path) }.getOrNull()
        }

        val format = MediaFormat.createVideoFormat(MIME_TYPE, width, height).apply {
            setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
            )
            setInteger(MediaFormat.KEY_BIT_RATE, BIT_RATE)
            setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, I_FRAME_INTERVAL)
        }

        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var inputSurface: android.view.Surface? = null
        var muxerStarted = false
        var trackIndex = -1
        var encodedFrameCount = 0L

        try {
            codec = MediaCodec.createEncoderByType(MIME_TYPE)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = codec.createInputSurface()
            codec.start()

            muxer = MediaMuxer(videoFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val bufferInfo = MediaCodec.BufferInfo()

            val thumbBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            var thumbSaved = false

            for (frameIndex in 0 until totalFrames) {
                coroutineContext.ensureActive()
                val t = frameIndex.toFloat() / (totalFrames - 1).coerceAtLeast(1)

                val canvas = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    inputSurface.lockHardwareCanvas()
                } else {
                    inputSurface.lockCanvas(null)
                }
                try {
                    drawSceneFrame(
                        canvas = canvas,
                        width = width,
                        height = height,
                        progress = t,
                        sceneNumber = sceneNumber,
                        prompt = prompt,
                        continuityContext = continuityContext,
                        style = style,
                        aspectRatio = aspectRatio,
                        durationSeconds = durationSeconds,
                        refBitmap = refBitmap
                    )
                } finally {
                    inputSurface.unlockCanvasAndPost(canvas)
                }

                if (!thumbSaved && frameIndex == totalFrames / 2) {
                    val thumbCanvas = Canvas(thumbBitmap)
                    drawSceneFrame(
                        canvas = thumbCanvas,
                        width = width,
                        height = height,
                        progress = t,
                        sceneNumber = sceneNumber,
                        prompt = prompt,
                        continuityContext = continuityContext,
                        style = style,
                        aspectRatio = aspectRatio,
                        durationSeconds = durationSeconds,
                        refBitmap = refBitmap
                    )
                    FileOutputStream(thumbFile).use { fos ->
                        thumbBitmap.compress(Bitmap.CompressFormat.JPEG, 88, fos)
                    }
                    thumbSaved = true
                }

                val drainResult = drainEncoder(
                    codec = codec,
                    muxer = muxer,
                    bufferInfo = bufferInfo,
                    endOfStream = false,
                    trackIndex = trackIndex,
                    muxerStarted = muxerStarted,
                    frameDurationUs = frameDurationUs,
                    encodedFrameCount = encodedFrameCount
                )
                trackIndex = drainResult.trackIndex
                muxerStarted = drainResult.muxerStarted
                encodedFrameCount = drainResult.encodedFrameCount

                onProgress(0.1f + 0.85f * ((frameIndex + 1).toFloat() / totalFrames))
            }

            if (!thumbSaved) {
                FileOutputStream(thumbFile).use { fos ->
                    thumbBitmap.compress(Bitmap.CompressFormat.JPEG, 88, fos)
                }
            }
            thumbBitmap.recycle()

            codec.signalEndOfInputStream()
            val finalDrain = drainEncoder(
                codec = codec,
                muxer = muxer,
                bufferInfo = bufferInfo,
                endOfStream = true,
                trackIndex = trackIndex,
                muxerStarted = muxerStarted,
                frameDurationUs = frameDurationUs,
                encodedFrameCount = encodedFrameCount
            )
            muxerStarted = finalDrain.muxerStarted
            onProgress(1f)
        } finally {
            refBitmap?.recycle()
            runCatching { inputSurface?.release() }
            runCatching {
                codec?.stop()
                codec?.release()
            }
            runCatching {
                if (muxerStarted) muxer?.stop()
                muxer?.release()
            }
        }

        if (!videoFile.exists() || videoFile.length() == 0L) {
            throw IllegalStateException("Failed to synthesize demo MP4 clip.")
        }

        SynthesizedDemoClip(
            videoFilePath = videoFile.absolutePath,
            thumbnailPath = thumbFile.absolutePath
        )
    }

    private data class DrainResult(
        val trackIndex: Int,
        val muxerStarted: Boolean,
        val encodedFrameCount: Long
    )

    private fun drainEncoder(
        codec: MediaCodec,
        muxer: MediaMuxer,
        bufferInfo: MediaCodec.BufferInfo,
        endOfStream: Boolean,
        trackIndex: Int,
        muxerStarted: Boolean,
        frameDurationUs: Long,
        encodedFrameCount: Long
    ): DrainResult {
        var currentTrackIndex = trackIndex
        var started = muxerStarted
        var frameCounter = encodedFrameCount
        val timeoutUs = if (endOfStream) 10_000L else 5_000L

        while (true) {
            val outputIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
            when {
                outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!endOfStream) break
                }
                outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (started) {
                        throw IllegalStateException("MediaCodec output format changed twice")
                    }
                    val newFormat = codec.outputFormat
                    currentTrackIndex = muxer.addTrack(newFormat)
                    muxer.start()
                    started = true
                }
                outputIndex >= 0 -> {
                    val encodedData = codec.getOutputBuffer(outputIndex)
                        ?: throw IllegalStateException("Encoder output buffer was null")

                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        bufferInfo.size = 0
                    }

                    if (bufferInfo.size > 0) {
                        if (!started) {
                            currentTrackIndex = muxer.addTrack(codec.outputFormat)
                            muxer.start()
                            started = true
                        }
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        bufferInfo.presentationTimeUs = frameCounter * frameDurationUs
                        frameCounter++
                        muxer.writeSampleData(currentTrackIndex, encodedData, bufferInfo)
                    }

                    codec.releaseOutputBuffer(outputIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        break
                    }
                }
            }
        }

        return DrainResult(currentTrackIndex, started, frameCounter)
    }

    private fun drawSceneFrame(
        canvas: Canvas,
        width: Int,
        height: Int,
        progress: Float,
        sceneNumber: Int,
        prompt: String,
        continuityContext: String,
        style: VideoStyle,
        aspectRatio: AspectRatioOption,
        durationSeconds: Int,
        refBitmap: Bitmap?
    ) {
        val w = width.toFloat()
        val h = height.toFloat()
        val isCartoon = style == VideoStyle.CARTOON_3D
        val seedPhase = sceneNumber * 1.15f

        val bgColors = if (isCartoon) {
            intArrayOf(
                Color.rgb(34, 16, 78),
                Color.rgb(88, 28, 135),
                Color.rgb(14, 116, 144)
            )
        } else {
            intArrayOf(
                Color.rgb(8, 6, 16),
                Color.rgb(42, 16, 82),
                Color.rgb(12, 10, 24)
            )
        }

        val shift = sin((progress * PI * 2.0) + seedPhase).toFloat() * 0.25f
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                w * (0.2f + shift),
                0f,
                w * (0.8f - shift),
                h,
                bgColors,
                floatArrayOf(0f, 0.52f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        if (refBitmap != null) {
            val scale = 1.0f + 0.08f * progress
            val imgRatio = refBitmap.width.toFloat() / refBitmap.height.toFloat().coerceAtLeast(1f)
            val viewRatio = w / h
            val baseW: Float
            val baseH: Float
            if (imgRatio > viewRatio) {
                baseH = h * scale
                baseW = baseH * imgRatio
            } else {
                baseW = w * scale
                baseH = baseW / imgRatio
            }
            val panX = (w - baseW) * (0.35f + 0.3f * progress)
            val panY = (h - baseH) * 0.5f
            val dst = RectF(panX, panY, panX + baseW, panY + baseH)
            val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = 205
            }
            canvas.drawBitmap(refBitmap, null, dst, imgPaint)

            val vignette = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    0f, 0f, 0f, h,
                    intArrayOf(Color.argb(150, 6, 5, 10), Color.argb(40, 6, 5, 10), Color.argb(215, 6, 5, 10)),
                    floatArrayOf(0f, 0.45f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, w, h, vignette)
        }

        // Animated volumetric orbs / motion particles
        val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until 7) {
            val angle = progress * 2f * PI.toFloat() + i * 0.9f + seedPhase
            val cx = w * (0.5f + 0.34f * cos(angle))
            val cy = h * (0.42f + 0.22f * sin(angle * 0.8f + i))
            val radius = (minOf(w, h) * (0.06f + 0.025f * (i % 3)))
            orbPaint.color = if (isCartoon) {
                Color.argb(65, 56 + i * 22, 189, 248)
            } else {
                Color.argb(55, 168, 85 + i * 15, 247)
            }
            canvas.drawCircle(cx, cy, radius, orbPaint)
        }

        // Cinematic letterbox bars for realistic cinematic style
        if (!isCartoon) {
            val barPaint = Paint().apply { color = Color.argb(165, 4, 3, 8) }
            val barHeight = h * 0.06f
            canvas.drawRect(0f, 0f, w, barHeight, barPaint)
            canvas.drawRect(0f, h - barHeight, w, h, barPaint)
        }

        // Top DEMO badge (always clearly distinguishes demo clips from real AI output)
        val badgeW = w * 0.86f
        val badgeLeft = (w - badgeW) / 2f
        val badgeTop = h * 0.08f
        val badgeHeight = h * 0.065f
        val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(215, 46, 28, 6)
        }
        val badgeStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.style = Paint.Style.STROKE
            strokeWidth = 2.5f
            color = Color.rgb(245, 158, 11)
        }
        val badgeRect = RectF(badgeLeft, badgeTop, badgeLeft + badgeW, badgeTop + badgeHeight)
        canvas.drawRoundRect(badgeRect, 16f, 16f, badgePaint)
        canvas.drawRoundRect(badgeRect, 16f, 16f, badgeStroke)

        val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(252, 211, 77)
            textSize = (minOf(w, h) * 0.032f).coerceIn(14f, 24f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val badgeCenterY = badgeRect.centerY() - (badgeTextPaint.descent() + badgeTextPaint.ascent()) / 2f
        canvas.drawText("DEMO PREVIEW • LOCAL SYNTHESIS", badgeRect.centerX(), badgeCenterY, badgeTextPaint)

        // Bottom Prompt & Metadata HUD
        val hudPadding = w * 0.06f
        val hudTop = h * 0.68f
        val hudRect = RectF(hudPadding, hudTop, w - hudPadding, h * 0.90f)
        val hudBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(185, 14, 10, 26)
        }
        val hudBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.style = Paint.Style.STROKE
            strokeWidth = 2f
            color = Color.argb(140, 168, 85, 247)
        }
        canvas.drawRoundRect(hudRect, 22f, 22f, hudBg)
        canvas.drawRoundRect(hudRect, 22f, 22f, hudBorder)

        val styleName = if (isCartoon) "3D CARTOON" else "REALISTIC CINEMATIC"
        val metaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(216, 180, 254)
            textSize = (minOf(w, h) * 0.030f).coerceIn(13f, 22f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        val textLeft = hudRect.left + 20f
        val metaY = hudRect.top + metaPaint.textSize + 18f
        canvas.drawText(
            "SCENE #$sceneNumber • $styleName • ${aspectRatio.label}",
            textLeft,
            metaY,
            metaPaint
        )

        val promptPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = (minOf(w, h) * 0.036f).coerceIn(15f, 26f)
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val clippedPrompt = prompt.trim().ifEmpty { "Untitled Scene" }.take(64)
        drawWrappedText(
            canvas = canvas,
            text = clippedPrompt,
            x = textLeft,
            y = metaY + promptPaint.textSize + 14f,
            maxWidth = hudRect.width() - 40f,
            paint = promptPaint,
            maxLines = 2
        )

        if (continuityContext.isNotBlank()) {
            val contPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(168, 158, 196)
                textSize = (minOf(w, h) * 0.026f).coerceIn(12f, 19f)
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            }
            canvas.drawText(
                "REF: ${continuityContext.trim().take(42)}",
                textLeft,
                hudRect.bottom - 34f,
                contPaint
            )
        }

        // Progress bar at bottom of HUD
        val barLeft = textLeft
        val barRight = hudRect.right - 20f
        val barY = hudRect.bottom - 16f
        val trackPaint = Paint().apply {
            color = Color.argb(90, 255, 255, 255)
            strokeWidth = 6f
            strokeCap = Paint.Cap.ROUND
        }
        val fillPaint = Paint().apply {
            color = Color.rgb(168, 85, 247)
            strokeWidth = 6f
            strokeCap = Paint.Cap.ROUND
        }
        canvas.drawLine(barLeft, barY, barRight, barY, trackPaint)
        canvas.drawLine(barLeft, barY, barLeft + (barRight - barLeft) * progress, barY, fillPaint)

        // Timecode corner
        val secNow = progress * durationSeconds
        val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(192, 132, 252)
            textSize = (minOf(w, h) * 0.028f).coerceIn(12f, 20f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(
            String.format("%.1fs / %ds", secNow, durationSeconds),
            hudRect.right - 20f,
            metaY,
            timePaint
        )
    }

    private fun drawWrappedText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        maxWidth: Float,
        paint: Paint,
        maxLines: Int
    ) {
        val words = text.split(" ")
        var line = StringBuilder()
        var currentY = y
        var lineCount = 0
        val bounds = Rect()

        for (word in words) {
            val candidate = if (line.isEmpty()) word else "$line $word"
            paint.getTextBounds(candidate, 0, candidate.length, bounds)
            if (bounds.width() > maxWidth && line.isNotEmpty()) {
                canvas.drawText(line.toString(), x, currentY, paint)
                lineCount++
                if (lineCount >= maxLines) return
                line = StringBuilder(word)
                currentY += paint.textSize * 1.28f
            } else {
                line = StringBuilder(candidate)
            }
        }
        if (line.isNotEmpty() && lineCount < maxLines) {
            canvas.drawText(line.toString(), x, currentY, paint)
        }
    }
}

package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.i18n.AppLanguage
import com.example.model.ProviderAdapterId
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.studioDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "studio_settings"
)

data class StudioSettings(
    val language: AppLanguage = AppLanguage.ENGLISH,
    val selectedAdapterId: ProviderAdapterId = ProviderAdapterId.DEMO_MODE,
    val backendBaseUrl: String = "",
    val backendClientToken: String = "",
    val activeProjectId: Long = -1L
)

class SettingsPreferencesRepository(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("app_language")
        val ADAPTER_ID = stringPreferencesKey("selected_adapter_id")
        val BACKEND_URL = stringPreferencesKey("backend_base_url")
        val BACKEND_TOKEN = stringPreferencesKey("backend_client_token")
        val ACTIVE_PROJECT_ID = longPreferencesKey("active_project_id")
    }

    val settingsFlow: Flow<StudioSettings> = context.studioDataStore.data.map { prefs ->
        val langCode = prefs[Keys.LANGUAGE] ?: AppLanguage.ENGLISH.code
        val language = AppLanguage.entries.firstOrNull { it.code == langCode } ?: AppLanguage.ENGLISH
        val adapterId = ProviderAdapterId.fromId(
            prefs[Keys.ADAPTER_ID] ?: ProviderAdapterId.DEMO_MODE.id
        )
        StudioSettings(
            language = language,
            selectedAdapterId = adapterId,
            backendBaseUrl = prefs[Keys.BACKEND_URL] ?: "",
            backendClientToken = prefs[Keys.BACKEND_TOKEN] ?: "",
            activeProjectId = prefs[Keys.ACTIVE_PROJECT_ID] ?: -1L
        )
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.studioDataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun saveProviderConfig(
        adapterId: ProviderAdapterId,
        backendBaseUrl: String,
        backendClientToken: String
    ) {
        context.studioDataStore.edit { prefs ->
            prefs[Keys.ADAPTER_ID] = adapterId.id
            prefs[Keys.BACKEND_URL] = backendBaseUrl.trim()
            prefs[Keys.BACKEND_TOKEN] = backendClientToken.trim()
        }
    }

    suspend fun setActiveProjectId(projectId: Long) {
        context.studioDataStore.edit { it[Keys.ACTIVE_PROJECT_ID] = projectId }
    }
}

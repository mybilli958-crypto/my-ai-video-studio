package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StudioDao {

    @Transaction
    @Query("SELECT * FROM story_projects ORDER BY updatedAt DESC")
    fun observeAllProjectsWithClips(): Flow<List<ProjectWithClips>>

    @Transaction
    @Query("SELECT * FROM story_projects WHERE id = :projectId")
    fun observeProjectWithClips(projectId: Long): Flow<ProjectWithClips?>

    @Query("SELECT * FROM story_projects WHERE id = :projectId")
    suspend fun getProjectById(projectId: Long): StoryProjectEntity?

    @Query("SELECT * FROM video_clips ORDER BY createdAt DESC LIMIT :limit")
    fun observeRecentClips(limit: Int = 12): Flow<List<VideoClipEntity>>

    @Query("SELECT * FROM video_clips WHERE projectId = :projectId ORDER BY orderIndex ASC")
    suspend fun getClipsForProject(projectId: Long): List<VideoClipEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: StoryProjectEntity): Long

    @Update
    suspend fun updateProject(project: StoryProjectEntity)

    @Query("DELETE FROM story_projects WHERE id = :projectId")
    suspend fun deleteProjectById(projectId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClip(clip: VideoClipEntity): Long

    @Update
    suspend fun updateClip(clip: VideoClipEntity)

    @Update
    suspend fun updateClips(clips: List<VideoClipEntity>)

    @Query("DELETE FROM video_clips WHERE id = :clipId")
    suspend fun deleteClipById(clipId: Long)

    @Transaction
    suspend fun swapClipsOrder(clipA: VideoClipEntity, clipB: VideoClipEntity) {
        updateClip(clipA.copy(orderIndex = clipB.orderIndex))
        updateClip(clipB.copy(orderIndex = clipA.orderIndex))
    }

    @Transaction
    suspend fun deleteClipAndReindex(projectId: Long, clipId: Long) {
        deleteClipById(clipId)
        val remaining = getClipsForProject(projectId).sortedBy { it.orderIndex }
        val reindexed = remaining.mapIndexed { index, clip -> clip.copy(orderIndex = index) }
        updateClips(reindexed)
    }
}

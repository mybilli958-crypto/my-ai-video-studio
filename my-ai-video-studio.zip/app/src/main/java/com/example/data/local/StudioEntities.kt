package com.example.data.local

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(tableName = "story_projects")
data class StoryProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val aspectRatioId: String,
    val styleId: String,
    val continuityNotes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val lastExportedPath: String? = null,
    val lastExportedAt: Long? = null
)

@Entity(
    tableName = "video_clips",
    foreignKeys = [
        ForeignKey(
            entity = StoryProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("projectId")]
)
data class VideoClipEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val orderIndex: Int,
    val prompt: String,
    val continuityContext: String = "",
    val styleId: String,
    val aspectRatioId: String,
    val durationSeconds: Int,
    val videoFilePath: String,
    val thumbnailPath: String,
    val referenceImagePath: String? = null,
    val originId: String,
    val continuityModeId: String,
    val providerName: String,
    val remoteGenerationId: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

data class ProjectWithClips(
    @Embedded val project: StoryProjectEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "projectId"
    )
    val clips: List<VideoClipEntity>
) {
    val orderedClips: List<VideoClipEntity>
        get() = clips.sortedBy { it.orderIndex }
}

package com.example.provider

import android.content.Context
import com.example.data.local.VideoClipEntity
import com.example.media.DemoMp4Synthesizer
import com.example.model.ClipOrigin
import com.example.model.ContinuityMode
import com.example.model.ProviderAdapterId
import com.example.model.ProviderCapabilities
import com.example.model.ProviderStatus
import com.example.model.VideoGenerationRequest
import com.example.model.VideoGenerationResult

interface VideoGenerationProvider {
    val capabilities: ProviderCapabilities

    suspend fun checkStatus(): ProviderStatus

    suspend fun generateClip(
        request: VideoGenerationRequest,
        onProgress: (Float, String) -> Unit
    ): VideoGenerationResult

    suspend fun extendClip(
        request: VideoGenerationRequest,
        previousClip: VideoClipEntity,
        onProgress: (Float, String) -> Unit
    ): VideoGenerationResult
}

class DemoVideoProvider(
    private val context: Context
) : VideoGenerationProvider {

    override val capabilities: ProviderCapabilities =
        ProviderCatalog.capabilitiesFor(ProviderAdapterId.DEMO_MODE)

    override suspend fun checkStatus(): ProviderStatus = ProviderStatus(
        isReachable = true,
        isDemo = true,
        providerLabel = capabilities.displayName,
        detailMessage = "Local Demo MP4 Synthesizer active. No external API key required."
    )

    override suspend fun generateClip(
        request: VideoGenerationRequest,
        onProgress: (Float, String) -> Unit
    ): VideoGenerationResult {
        return try {
            onProgress(0.05f, "Preparing demo synthesis canvas...")
            val synthesized = DemoMp4Synthesizer.synthesizeClip(
                context = context,
                sceneNumber = request.sceneNumber,
                prompt = request.prompt,
                continuityContext = request.continuityContext,
                style = request.style,
                aspectRatio = request.aspectRatio,
                durationSeconds = request.durationSeconds,
                referenceImagePath = request.referenceImagePath,
                onProgress = { p ->
                    onProgress(p, "Encoding Demo MP4 (${(p * 100).toInt()}%)...")
                }
            )
            val continuity = if (request.referenceImagePath != null) {
                ContinuityMode.IMAGE_REFERENCE
            } else {
                ContinuityMode.NONE
            }
            VideoGenerationResult.Success(
                videoFilePath = synthesized.videoFilePath,
                thumbnailPath = synthesized.thumbnailPath,
                durationSeconds = request.durationSeconds,
                origin = ClipOrigin.DEMO_SYNTHESIZED,
                continuityMode = continuity,
                providerName = capabilities.displayName,
                remoteGenerationId = null
            )
        } catch (e: Exception) {
            VideoGenerationResult.Error(
                message = "Demo MP4 synthesis failed: ${e.localizedMessage ?: "Unknown codec error"}",
                technicalDetail = e.stackTraceToString().take(400)
            )
        }
    }

    override suspend fun extendClip(
        request: VideoGenerationRequest,
        previousClip: VideoClipEntity,
        onProgress: (Float, String) -> Unit
    ): VideoGenerationResult {
        return try {
            onProgress(0.05f, "Linking previous scene's last frame...")
            val synthesized = DemoMp4Synthesizer.synthesizeClip(
                context = context,
                sceneNumber = request.sceneNumber,
                prompt = request.prompt,
                continuityContext = request.continuityContext,
                style = request.style,
                aspectRatio = request.aspectRatio,
                durationSeconds = request.durationSeconds,
                referenceImagePath = request.referenceImagePath,
                onProgress = { p ->
                    onProgress(p, "Encoding Demo Extension MP4 (${(p * 100).toInt()}%)...")
                }
            )
            VideoGenerationResult.Success(
                videoFilePath = synthesized.videoFilePath,
                thumbnailPath = synthesized.thumbnailPath,
                durationSeconds = request.durationSeconds,
                origin = ClipOrigin.DEMO_SYNTHESIZED,
                continuityMode = ContinuityMode.LAST_FRAME_REFERENCE,
                providerName = capabilities.displayName,
                remoteGenerationId = null
            )
        } catch (e: Exception) {
            VideoGenerationResult.Error(
                message = "Demo extension synthesis failed: ${e.localizedMessage ?: "Unknown codec error"}",
                technicalDetail = e.stackTraceToString().take(400)
            )
        }
    }
}

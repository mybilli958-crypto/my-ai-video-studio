package com.example.provider

import com.example.model.AspectRatioOption
import com.example.model.ProviderAdapterId
import com.example.model.ProviderCapabilities

object ProviderCatalog {

    val allCapabilities: Map<ProviderAdapterId, ProviderCapabilities> = mapOf(
        ProviderAdapterId.DEMO_MODE to ProviderCapabilities(
            adapterId = ProviderAdapterId.DEMO_MODE,
            displayName = "Demo Mode (Local MP4)",
            isDemo = true,
            requiresBackendUrl = false,
            supportsTextToVideo = true,
            supportsImageToVideo = true,
            supportsNativeVideoContinuation = false,
            supportedDurationsSeconds = listOf(3, 5, 8),
            supportedAspectRatios = listOf(
                AspectRatioOption.PORTRAIT_9_16,
                AspectRatioOption.LANDSCAPE_16_9,
                AspectRatioOption.SQUARE_1_1
            ),
            quotaSummaryEn = "Local on-device demo synthesis (no cloud quota consumed). Output clips carry a DEMO watermark.",
            quotaSummaryBn = "ফোনের ভেতরেই ডেমো MP4 তৈরি হয় (কোনো ক্লাউড কোটা খরচ হয় না)। প্রতিটি ক্লিপে DEMO ওয়াটারমার্ক থাকে।",
            limitationsEn = "Does not run generative AI diffusion models. Simulates scene cards, reference frame motion, and multi-clip MP4 export.",
            limitationsBn = "আসল এআই ডিফিউশন মডেল চালায় না। সিন কার্ড, রেফারেন্স ফ্রেম মোশন ও MP4 এক্সপোর্ট পরীক্ষা করার জন্য তৈরি।"
        ),
        ProviderAdapterId.CUSTOM_BACKEND to ProviderCapabilities(
            adapterId = ProviderAdapterId.CUSTOM_BACKEND,
            displayName = "Custom Secure Backend",
            isDemo = false,
            requiresBackendUrl = true,
            supportsTextToVideo = true,
            supportsImageToVideo = true,
            supportsNativeVideoContinuation = true,
            supportedDurationsSeconds = listOf(4, 5, 8, 10),
            supportedAspectRatios = listOf(
                AspectRatioOption.PORTRAIT_9_16,
                AspectRatioOption.LANDSCAPE_16_9,
                AspectRatioOption.SQUARE_1_1
            ),
            quotaSummaryEn = "Depends on the upstream video API configured in your backend environment variables.",
            quotaSummaryBn = "আপনার ব্যাকএন্ড সার্ভারে সেট করা ভিডিও API প্রোভাইডারের কোটার ওপর নির্ভরশীল।",
            limitationsEn = "Requires a reachable HTTPS backend implementing /health, /api/v1/videos/generate, and /api/v1/videos/extend.",
            limitationsBn = "/health, /api/v1/videos/generate এবং /api/v1/videos/extend এন্ডপয়েন্টসহ একটি সচল HTTPS ব্যাকএন্ড প্রয়োজন।"
        ),
        ProviderAdapterId.GOOGLE_VEO_BACKEND to ProviderCapabilities(
            adapterId = ProviderAdapterId.GOOGLE_VEO_BACKEND,
            displayName = "Google Veo (via Backend)",
            isDemo = false,
            requiresBackendUrl = true,
            supportsTextToVideo = true,
            supportsImageToVideo = true,
            supportsNativeVideoContinuation = true,
            supportedDurationsSeconds = listOf(5, 8),
            supportedAspectRatios = listOf(
                AspectRatioOption.PORTRAIT_9_16,
                AspectRatioOption.LANDSCAPE_16_9
            ),
            quotaSummaryEn = "Paid Google Cloud / Vertex AI or Gemini API billing & rate-limited RPM/daily quotas apply on backend. No unlimited free tier.",
            quotaSummaryBn = "Google Cloud / Vertex AI বা Gemini API-এর পেইড বিলিং ও নির্ধারিত কোটা প্রযোজ্য। আনলিমিটেড ফ্রি জেনারেশন নেই।",
            limitationsEn = "Requires server-side service account or API key on your backend. Video extension applies only to supported Veo models.",
            limitationsBn = "সার্ভার-সাইড কী/সার্ভিস অ্যাকাউন্টসহ ব্যাকএন্ড প্রয়োজন। শুধু সমর্থিত Veo মডেলেই ভিডিও এক্সটেনশন কাজ করে।"
        ),
        ProviderAdapterId.RUNWAY_BACKEND to ProviderCapabilities(
            adapterId = ProviderAdapterId.RUNWAY_BACKEND,
            displayName = "Runway Gen-3/4 (via Backend)",
            isDemo = false,
            requiresBackendUrl = true,
            supportsTextToVideo = true,
            supportsImageToVideo = true,
            supportsNativeVideoContinuation = false,
            supportedDurationsSeconds = listOf(5, 10),
            supportedAspectRatios = listOf(
                AspectRatioOption.PORTRAIT_9_16,
                AspectRatioOption.LANDSCAPE_16_9,
                AspectRatioOption.SQUARE_1_1
            ),
            quotaSummaryEn = "Per-second credit billing via official Runway API on your backend. Credits are finite and metered.",
            quotaSummaryBn = "অফিশিয়াল Runway API-এ প্রতি সেকেন্ড অনুযায়ী ক্রেডিট খরচ হয়। ফ্রি আনলিমিটেড নয়।",
            limitationsEn = "Uses last-frame image reference for scene continuity unless native extend is enabled on your backend adapter.",
            limitationsBn = "নেটিভ কন্টিনিউয়েশন না থাকায় আগের ক্লিপের শেষ ফ্রেম ইমেজ-রেফারেন্স হিসেবে ব্যবহৃত হয়।"
        ),
        ProviderAdapterId.LUMA_BACKEND to ProviderCapabilities(
            adapterId = ProviderAdapterId.LUMA_BACKEND,
            displayName = "Luma Dream Machine (via Backend)",
            isDemo = false,
            requiresBackendUrl = true,
            supportsTextToVideo = true,
            supportsImageToVideo = true,
            supportsNativeVideoContinuation = true,
            supportedDurationsSeconds = listOf(5, 9),
            supportedAspectRatios = listOf(
                AspectRatioOption.PORTRAIT_9_16,
                AspectRatioOption.LANDSCAPE_16_9,
                AspectRatioOption.SQUARE_1_1
            ),
            quotaSummaryEn = "Metered API credits & concurrency limits enforced by Luma API on your backend server.",
            quotaSummaryBn = "Luma API-এর নির্ধারিত পেইড ক্রেডিট ও কনকারেন্সি লিমিট প্রযোজ্য।",
            limitationsEn = "Requires server-side LUMA_API_KEY in backend environment variables; never store keys in the Android app.",
            limitationsBn = "সার্ভারের environment variable-এ LUMA_API_KEY থাকতে হবে; অ্যাপে কোনো কী রাখা যাবে না।"
        )
    )

    fun capabilitiesFor(adapterId: ProviderAdapterId): ProviderCapabilities =
        allCapabilities[adapterId] ?: allCapabilities.getValue(ProviderAdapterId.DEMO_MODE)
}

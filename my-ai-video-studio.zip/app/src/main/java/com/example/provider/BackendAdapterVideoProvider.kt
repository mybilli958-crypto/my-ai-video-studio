package com.example.provider

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.util.Base64
import com.example.data.local.VideoClipEntity
import com.example.model.ClipOrigin
import com.example.model.ContinuityMode
import com.example.model.ProviderCapabilities
import com.example.model.ProviderStatus
import com.example.model.VideoGenerationRequest
import com.example.model.VideoGenerationResult
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class BackendHealthResponse(
    val status: String? = null,
    val provider: String? = null,
    val supportsImageToVideo: Boolean? = null,
    val supportsNativeVideoContinuation: Boolean? = null,
    val supportedDurationsSeconds: List<Int>? = null,
    val quotaMessage: String? = null
)

@JsonClass(generateAdapter = true)
data class BackendGenerateRequest(
    val adapterProfile: String,
    val prompt: String,
    val continuityContext: String,
    val style: String,
    val aspectRatio: String,
    val durationSeconds: Int,
    val referenceImageBase64: String? = null
)

@JsonClass(generateAdapter = true)
data class BackendExtendRequest(
    val adapterProfile: String,
    val prompt: String,
    val continuityContext: String,
    val style: String,
    val aspectRatio: String,
    val durationSeconds: Int,
    val previousGenerationId: String? = null,
    val lastFrameImageBase64: String? = null
)

@JsonClass(generateAdapter = true)
data class BackendVideoResponse(
    val status: String? = null,
    val videoUrl: String? = null,
    val generationId: String? = null,
    val providerName: String? = null,
    val continuityMode: String? = null,
    val durationSeconds: Int? = null,
    val error: String? = null
)

interface VideoBackendApiService {
    @GET("health")
    suspend fun getHealth(
        @Header("Authorization") authHeader: String?
    ): Response<BackendHealthResponse>

    @POST("api/v1/videos/generate")
    suspend fun generateVideo(
        @Header("Authorization") authHeader: String?,
        @Body body: BackendGenerateRequest
    ): Response<BackendVideoResponse>

    @POST("api/v1/videos/extend")
    suspend fun extendVideo(
        @Header("Authorization") authHeader: String?,
        @Body body: BackendExtendRequest
    ): Response<BackendVideoResponse>
}

class BackendAdapterVideoProvider(
    private val context: Context,
    override val capabilities: ProviderCapabilities,
    private val baseUrl: String,
    private val bearerToken: String
) : VideoGenerationProvider {

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun authHeaderOrNull(): String? =
        bearerToken.trim().takeIf { it.isNotEmpty() }?.let { "Bearer $it" }

    private fun normalizedBaseUrl(): String? {
        val trimmed = baseUrl.trim()
        if (trimmed.isEmpty()) return null
        if (!trimmed.startsWith("https://") && !trimmed.startsWith("http://")) return null
        return if (trimmed.endsWith("/")) trimmed else "$trimmed/"
    }

    private fun createApiService(validUrl: String): VideoBackendApiService {
        return Retrofit.Builder()
            .baseUrl(validUrl)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(VideoBackendApiService::class.java)
    }

    override suspend fun checkStatus(): ProviderStatus = withContext(Dispatchers.IO) {
        val url = normalizedBaseUrl()
            ?: return@withContext ProviderStatus(
                isReachable = false,
                isDemo = false,
                providerLabel = capabilities.displayName,
                detailMessage = "No valid http(s) backend URL configured."
            )

        try {
            val response = createApiService(url).getHealth(authHeaderOrNull())
            if (response.isSuccessful) {
                val body = response.body()
                val remoteProvider = body?.provider ?: capabilities.displayName
                val quotaMsg = body?.quotaMessage ?: "Backend reachable (${response.code()})."
                ProviderStatus(
                    isReachable = true,
                    isDemo = false,
                    providerLabel = remoteProvider,
                    detailMessage = quotaMsg
                )
            } else {
                ProviderStatus(
                    isReachable = false,
                    isDemo = false,
                    providerLabel = capabilities.displayName,
                    detailMessage = "Backend returned HTTP ${response.code()}: ${response.message()}"
                )
            }
        } catch (e: Exception) {
            ProviderStatus(
                isReachable = false,
                isDemo = false,
                providerLabel = capabilities.displayName,
                detailMessage = "Connection failed: ${e.localizedMessage ?: "Network error"}"
            )
        }
    }

    override suspend fun generateClip(
        request: VideoGenerationRequest,
        onProgress: (Float, String) -> Unit
    ): VideoGenerationResult = withContext(Dispatchers.IO) {
        val url = normalizedBaseUrl()
            ?: return@withContext VideoGenerationResult.Error(
                message = "Backend proxy URL is missing or invalid. Configure a valid https:// URL in Settings or switch to Demo Mode."
            )

        try {
            onProgress(0.15f, "Submitting job to secure backend...")
            val refBase64 = request.referenceImagePath?.let { encodeFileBase64(it) }
            val api = createApiService(url)
            val response = api.generateVideo(
                authHeader = authHeaderOrNull(),
                body = BackendGenerateRequest(
                    adapterProfile = capabilities.adapterId.id,
                    prompt = request.prompt,
                    continuityContext = request.continuityContext,
                    style = request.style.id,
                    aspectRatio = request.aspectRatio.id,
                    durationSeconds = request.durationSeconds,
                    referenceImageBase64 = refBase64
                )
            )
            handleBackendResponse(response, ContinuityMode.IMAGE_REFERENCE, refBase64 != null, onProgress)
        } catch (e: Exception) {
            VideoGenerationResult.Error(
                message = "External video generation failed: ${e.localizedMessage ?: "Network error"}",
                technicalDetail = e.javaClass.simpleName
            )
        }
    }

    override suspend fun extendClip(
        request: VideoGenerationRequest,
        previousClip: VideoClipEntity,
        onProgress: (Float, String) -> Unit
    ): VideoGenerationResult = withContext(Dispatchers.IO) {
        val url = normalizedBaseUrl()
            ?: return@withContext VideoGenerationResult.Error(
                message = "Backend proxy URL is missing or invalid. Configure a valid https:// URL in Settings or switch to Demo Mode."
            )

        try {
            val useNativeContinuation = capabilities.supportsNativeVideoContinuation &&
                !previousClip.remoteGenerationId.isNullOrBlank()

            onProgress(
                0.15f,
                if (useNativeContinuation) {
                    "Calling official video continuation endpoint..."
                } else {
                    "Sending previous clip's last frame as image reference..."
                }
            )

            val lastFrameBase64 = request.referenceImagePath?.let { encodeFileBase64(it) }
            val api = createApiService(url)
            val response = api.extendVideo(
                authHeader = authHeaderOrNull(),
                body = BackendExtendRequest(
                    adapterProfile = capabilities.adapterId.id,
                    prompt = request.prompt,
                    continuityContext = request.continuityContext,
                    style = request.style.id,
                    aspectRatio = request.aspectRatio.id,
                    durationSeconds = request.durationSeconds,
                    previousGenerationId = if (useNativeContinuation) previousClip.remoteGenerationId else null,
                    lastFrameImageBase64 = lastFrameBase64
                )
            )

            val defaultMode = if (useNativeContinuation) {
                ContinuityMode.NATIVE_VIDEO_EXTENSION
            } else {
                ContinuityMode.LAST_FRAME_REFERENCE
            }
            handleBackendResponse(response, defaultMode, true, onProgress)
        } catch (e: Exception) {
            VideoGenerationResult.Error(
                message = "External video extension failed: ${e.localizedMessage ?: "Network error"}",
                technicalDetail = e.javaClass.simpleName
            )
        }
    }

    private fun handleBackendResponse(
        response: Response<BackendVideoResponse>,
        defaultContinuityMode: ContinuityMode,
        hadReference: Boolean,
        onProgress: (Float, String) -> Unit
    ): VideoGenerationResult {
        if (!response.isSuccessful) {
            val errorText = response.errorBody()?.string()?.take(250)
            return VideoGenerationResult.Error(
                message = "Backend returned HTTP ${response.code()} (${response.message()}).",
                technicalDetail = errorText
            )
        }

        val body = response.body()
        if (body == null) {
            return VideoGenerationResult.Error("Backend returned an empty JSON response.")
        }
        if (!body.error.isNullOrBlank()) {
            return VideoGenerationResult.Error(body.error)
        }
        val videoUrl = body.videoUrl?.takeIf { it.isNotBlank() }
            ?: return VideoGenerationResult.Error(
                "Provider did not return a valid videoUrl. No clip was created."
            )

        onProgress(0.65f, "Downloading rendered MP4 from backend...")
        val downloadedFile = downloadVideoFile(videoUrl)
            ?: return VideoGenerationResult.Error(
                "Failed to download MP4 from returned videoUrl: $videoUrl"
            )

        onProgress(0.90f, "Extracting clip thumbnail...")
        val thumbPath = extractThumbnail(downloadedFile) ?: ""

        val continuityMode = when (body.continuityMode) {
            "native_video_extension" -> ContinuityMode.NATIVE_VIDEO_EXTENSION
            "last_frame_reference" -> ContinuityMode.LAST_FRAME_REFERENCE
            "image_reference" -> ContinuityMode.IMAGE_REFERENCE
            else -> if (hadReference) defaultContinuityMode else ContinuityMode.NONE
        }

        onProgress(1f, "Complete")
        return VideoGenerationResult.Success(
            videoFilePath = downloadedFile.absolutePath,
            thumbnailPath = thumbPath,
            durationSeconds = body.durationSeconds ?: 5,
            origin = ClipOrigin.EXTERNAL_PROVIDER,
            continuityMode = continuityMode,
            providerName = body.providerName ?: capabilities.displayName,
            remoteGenerationId = body.generationId
        )
    }

    private fun downloadVideoFile(videoUrl: String): File? {
        return try {
            val req = Request.Builder().url(videoUrl).build()
            okHttpClient.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return null
                val body = res.body ?: return null
                val videosDir = File(context.filesDir, "videos").apply { mkdirs() }
                val outFile = File(videosDir, "ai_clip_${System.currentTimeMillis()}.mp4")
                FileOutputStream(outFile).use { out ->
                    body.byteStream().copyTo(out)
                }
                if (outFile.exists() && outFile.length() > 0L) outFile else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun extractThumbnail(videoFile: File): String? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(videoFile.absolutePath)
            val bmp = retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: return null
            val thumbsDir = File(context.filesDir, "thumbs").apply { mkdirs() }
            val thumbFile = File(thumbsDir, "thumb_${System.currentTimeMillis()}.jpg")
            FileOutputStream(thumbFile).use { fos ->
                bmp.compress(Bitmap.CompressFormat.JPEG, 88, fos)
            }
            bmp.recycle()
            thumbFile.absolutePath
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun encodeFileBase64(path: String): String? {
        return try {
            val bytes = File(path).readBytes()
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (_: Exception) {
            null
        }
    }
}

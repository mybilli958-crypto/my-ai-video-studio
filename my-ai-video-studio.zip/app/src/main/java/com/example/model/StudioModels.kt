package com.example.model

enum class VideoStyle(val id: String) {
    REALISTIC_CINEMATIC("realistic_cinematic"),
    CARTOON_3D("3d_cartoon");

    companion object {
        fun fromId(id: String): VideoStyle =
            entries.firstOrNull { it.id == id } ?: REALISTIC_CINEMATIC
    }
}

enum class AspectRatioOption(
    val id: String,
    val label: String,
    val encodeWidth: Int,
    val encodeHeight: Int,
    val displayRatio: Float
) {
    PORTRAIT_9_16("9:16", "9:16", 544, 960, 9f / 16f),
    LANDSCAPE_16_9("16:9", "16:9", 960, 544, 16f / 9f),
    SQUARE_1_1("1:1", "1:1", 640, 640, 1f);

    companion object {
        fun fromId(id: String): AspectRatioOption =
            entries.firstOrNull { it.id == id } ?: PORTRAIT_9_16
    }
}

enum class ClipOrigin(val id: String) {
    DEMO_SYNTHESIZED("demo"),
    EXTERNAL_PROVIDER("external_ai");

    companion object {
        fun fromId(id: String): ClipOrigin =
            entries.firstOrNull { it.id == id } ?: DEMO_SYNTHESIZED
    }
}

enum class ContinuityMode(val id: String) {
    NONE("none"),
    IMAGE_REFERENCE("image_reference"),
    LAST_FRAME_REFERENCE("last_frame_reference"),
    NATIVE_VIDEO_EXTENSION("native_video_extension");

    companion object {
        fun fromId(id: String): ContinuityMode =
            entries.firstOrNull { it.id == id } ?: NONE
    }
}

enum class ProviderAdapterId(val id: String) {
    DEMO_MODE("demo_mode"),
    CUSTOM_BACKEND("custom_backend"),
    GOOGLE_VEO_BACKEND("google_veo_backend"),
    RUNWAY_BACKEND("runway_backend"),
    LUMA_BACKEND("luma_backend");

    companion object {
        fun fromId(id: String): ProviderAdapterId =
            entries.firstOrNull { it.id == id } ?: DEMO_MODE
    }
}

data class ProviderCapabilities(
    val adapterId: ProviderAdapterId,
    val displayName: String,
    val isDemo: Boolean,
    val requiresBackendUrl: Boolean,
    val supportsTextToVideo: Boolean,
    val supportsImageToVideo: Boolean,
    val supportsNativeVideoContinuation: Boolean,
    val supportedDurationsSeconds: List<Int>,
    val supportedAspectRatios: List<AspectRatioOption>,
    val quotaSummaryEn: String,
    val quotaSummaryBn: String,
    val limitationsEn: String,
    val limitationsBn: String
)

data class ProviderStatus(
    val isReachable: Boolean,
    val isDemo: Boolean,
    val providerLabel: String,
    val detailMessage: String
)

data class VideoGenerationRequest(
    val projectId: Long,
    val sceneNumber: Int,
    val prompt: String,
    val continuityContext: String,
    val style: VideoStyle,
    val aspectRatio: AspectRatioOption,
    val durationSeconds: Int,
    val referenceImagePath: String? = null,
    val previousClipId: Long? = null,
    val previousRemoteGenerationId: String? = null,
    val isExtensionFlow: Boolean = false
)

sealed interface VideoGenerationResult {
    data class Success(
        val videoFilePath: String,
        val thumbnailPath: String,
        val durationSeconds: Int,
        val origin: ClipOrigin,
        val continuityMode: ContinuityMode,
        val providerName: String,
        val remoteGenerationId: String? = null
    ) : VideoGenerationResult

    data class Error(
        val message: String,
        val technicalDetail: String? = null
    ) : VideoGenerationResult
}

sealed interface GenerationUiState {
    data object Idle : GenerationUiState
    data class Generating(val progress: Float, val statusLabel: String) : GenerationUiState
    data class Error(val message: String, val detail: String? = null) : GenerationUiState
}

sealed interface ExportUiState {
    data object Idle : ExportUiState
    data class Exporting(val progressPercent: Int) : ExportUiState
    data class Completed(
        val outputFilePath: String,
        val fileSizeBytes: Long,
        val clipCount: Int,
        val savedToGalleryUri: String? = null
    ) : ExportUiState
    data class Failed(val errorMessage: String) : ExportUiState
}
